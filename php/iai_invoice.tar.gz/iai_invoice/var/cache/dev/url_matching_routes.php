<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/c/an' => [[['_route' => 'angular_url', '_controller' => 'App\\Controller\\AngularController::angular_url'], null, null, null, false, false, null]],
        '/c' => [[['_route' => 'customers_main', '_controller' => 'App\\Controller\\CustomersController::customers_main'], null, null, null, false, false, null]],
        '/i' => [[['_route' => 'invoices_main', '_controller' => 'App\\Controller\\InvoicesController::invoices_main'], null, null, null, false, false, null]],
        '/i/l' => [[['_route' => 'invoices_list', '_controller' => 'App\\Controller\\InvoicesController::invoices_list'], null, null, null, false, false, null]],
        '/t' => [[['_route' => 'items_list', '_controller' => 'App\\Controller\\ItemsController::items_list'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'index', '_controller' => 'App\\Controller\\MyFirmController::index'], null, null, null, false, false, null]],
        '/m' => [[['_route' => 'myfirm_main', '_controller' => 'App\\Controller\\MyFirmController::myfirm_main'], null, null, null, false, false, null]],
        '/m/e' => [[['_route' => 'myfirm_edit', '_controller' => 'App\\Controller\\MyFirmController::myfirm_edit'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/c/(?'
                    .'|s/([^/]++)(*:185)'
                    .'|e(?:/([^/]++))?(*:208)'
                .')'
                .'|/i/(?'
                    .'|a(?'
                        .'|(?:/([^/]++))?(*:241)'
                        .'|i/([^/]++)(?'
                            .'|(*:262)'
                            .'|(?:/([^/]++))?(*:284)'
                        .')'
                    .')'
                    .'|s/([^/]++)(*:304)'
                    .'|e/([^/]++)(*:322)'
                    .'|d(?'
                        .'|i/([^/]++)/([^/]++)/([^/]++)(*:362)'
                        .'|/([^/]++)(*:379)'
                    .')'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        185 => [[['_route' => 'customer_show', '_controller' => 'App\\Controller\\CustomersController::customer_show'], ['customer_id'], null, null, false, true, null]],
        208 => [[['_route' => 'customer_add_edit', 'customer_id' => null, '_controller' => 'App\\Controller\\CustomersController::customer_add_edit'], ['customer_id'], null, null, false, true, null]],
        241 => [[['_route' => 'invoice_add', 'customer_id' => null, '_controller' => 'App\\Controller\\InvoicesController::invoice_add'], ['customer_id'], null, null, false, true, null]],
        262 => [[['_route' => 'invoice_add_item_choice', '_controller' => 'App\\Controller\\InvoicesController::invoice_add_item_choice'], ['invoice_id'], null, null, false, true, null]],
        284 => [[['_route' => 'invoice_add_item', 'item_id' => null, '_controller' => 'App\\Controller\\InvoicesController::invoice_add_item'], ['invoice_id', 'item_id'], null, null, false, true, null]],
        304 => [[['_route' => 'invoice_show', '_controller' => 'App\\Controller\\InvoicesController::invoice_show'], ['invoice_id'], null, null, false, true, null]],
        322 => [[['_route' => 'invoice_edit', '_controller' => 'App\\Controller\\InvoicesController::invoice_edit'], ['invoice_id'], null, null, false, true, null]],
        362 => [[['_route' => 'invoice_del_item', '_controller' => 'App\\Controller\\InvoicesController::invoice_del_item'], ['invoice_id', 'item_id', 'iid'], null, null, false, true, null]],
        379 => [
            [['_route' => 'invoice_delete', '_controller' => 'App\\Controller\\InvoicesController::invoice_delete'], ['invoice_id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
