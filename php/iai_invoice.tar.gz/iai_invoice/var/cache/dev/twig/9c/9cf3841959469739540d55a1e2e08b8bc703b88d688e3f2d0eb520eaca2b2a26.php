<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* invoices/invoices_main.html.twig */
class __TwigTemplate_276de004c915679a6f59be8bfa84b1ee5e15d6bc44247d616d7848610e699543 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'base_nav_main_div' => [$this, 'block_base_nav_main_div'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "base/base_nonav.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoices_main.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoices_main.html.twig"));

        $this->parent = $this->loadTemplate("base/base_nonav.html.twig", "invoices/invoices_main.html.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 16
    public function block_base_nav_main_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_main_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_main_div"));

        // line 17
        echo "
    <div class=\"alert alert-info\" role=\"alert\">
        Faktury
    </div>

    <div class=\"list-group\">
        <a href=\"";
        // line 23
        echo "\" class=\"list-group-item list-group-item-action\">
            faktury
        </a>
        <a href=\"";
        // line 26
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("items_list");
        echo "\" class=\"list-group-item list-group-item-action\">
            towary
        </a>
        <a href=\"";
        // line 29
        echo "\" class=\"list-group-item list-group-item-action\">
            klienci
        </a>
        <a href=\"";
        // line 32
        echo "\" class=\"list-group-item list-group-item-action\">
            dane własne
        </a>
        <a href=\"#\" class=\"list-group-item list-group-item-action\">
            linki do rozwiązania na GIT
        </a>
        <a href=\"#\" class=\"list-group-item list-group-item-action\">
            linki do dokumentacji etc
        </a>
    </div>

    <div class=\"alert alert-info\" role=\"alert\">
        Opierałem się na wiedzy księgowej :-) <a href=\"https://pl.wikipedia.org/wiki/Faktura_(dokument)\" target=\"_blank\">stąd</a>.<br>
        Przykładowa faktura <a href=\"https://www.rapex.net.pl/public/assets/przyk%C5%82adowa%20faktura.png\" target=\"_blank\">przykładowa faktura</a>.
    </div>

    <div class=\"alert alert-info\" role=\"alert\">
        Użyłem:<br>
        <ul>
            <li>Python3/Django3 - prototyp</li>
            <li>MySQL</li>
            <li>PHP7/Symfony5</li>
            <li>Bootstrap4, jQuery, AngularJS</li>
        </ul>
        Wersja zadaniowa, bez logowania i ze sporą ilością komentarzy.<br>
        Użyto utworzone konto Gmail do wysyłania maili, zasymulowano Rabbit do tworzenia PDF (faktycznie nie użyłem tutaj mech. asynchronicznych).
    </div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "invoices/invoices_main.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  92 => 32,  87 => 29,  81 => 26,  76 => 23,  68 => 17,  58 => 16,  35 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'invoices/invoices_main.html.twig' #}

{% extends \"base/base_nonav.html.twig\" %}

{# comment %}
    główna rozwiązania,
    tutaj odgałęzienia do:
    -edycji swoich danych,
    -tworzenia odbiorców,
    -listowania faktur,
    -tworzenia faktury,
    -usuwania faktur,
{% endcomment #}


{% block base_nav_main_div %}

    <div class=\"alert alert-info\" role=\"alert\">
        Faktury
    </div>

    <div class=\"list-group\">
        <a href=\"{# url 'invoices_list' #}\" class=\"list-group-item list-group-item-action\">
            faktury
        </a>
        <a href=\"{{ path('items_list') }}\" class=\"list-group-item list-group-item-action\">
            towary
        </a>
        <a href=\"{# url 'customers_main' #}\" class=\"list-group-item list-group-item-action\">
            klienci
        </a>
        <a href=\"{# url 'myfirm_main' #}\" class=\"list-group-item list-group-item-action\">
            dane własne
        </a>
        <a href=\"#\" class=\"list-group-item list-group-item-action\">
            linki do rozwiązania na GIT
        </a>
        <a href=\"#\" class=\"list-group-item list-group-item-action\">
            linki do dokumentacji etc
        </a>
    </div>

    <div class=\"alert alert-info\" role=\"alert\">
        Opierałem się na wiedzy księgowej :-) <a href=\"https://pl.wikipedia.org/wiki/Faktura_(dokument)\" target=\"_blank\">stąd</a>.<br>
        Przykładowa faktura <a href=\"https://www.rapex.net.pl/public/assets/przyk%C5%82adowa%20faktura.png\" target=\"_blank\">przykładowa faktura</a>.
    </div>

    <div class=\"alert alert-info\" role=\"alert\">
        Użyłem:<br>
        <ul>
            <li>Python3/Django3 - prototyp</li>
            <li>MySQL</li>
            <li>PHP7/Symfony5</li>
            <li>Bootstrap4, jQuery, AngularJS</li>
        </ul>
        Wersja zadaniowa, bez logowania i ze sporą ilością komentarzy.<br>
        Użyto utworzone konto Gmail do wysyłania maili, zasymulowano Rabbit do tworzenia PDF (faktycznie nie użyłem tutaj mech. asynchronicznych).
    </div>

{% endblock %}

", "invoices/invoices_main.html.twig", "/home/wiks/Pulpit/iai_task/php/iai_invoice/templates/invoices/invoices_main.html.twig");
    }
}
