<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* invoices/invoice_add_item_choice.html.twig */
class __TwigTemplate_fedb86443fe7197841097b520e56fb5877a897686dde8a6f491504ac18204b4e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'base_left_part_for_item_select' => [$this, 'block_base_left_part_for_item_select'],
            'base_form_main_lower_buttons' => [$this, 'block_base_form_main_lower_buttons'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "invoices/invoice_edit_common_pure.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_add_item_choice.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_add_item_choice.html.twig"));

        $this->parent = $this->loadTemplate("invoices/invoice_edit_common_pure.html.twig", "invoices/invoice_add_item_choice.html.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 10
    public function block_base_left_part_for_item_select($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_left_part_for_item_select"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_left_part_for_item_select"));

        // line 11
        echo "
    ";
        // line 13
        echo "
    <div ng-app=\"myApp\" ng-controller=\"custCtrl\">
        <div class=\"container\">

            <div class=\"row\">
                <div class=\"col\">

                    <div class=\"alert alert-info\" role=\"alert\">
                        Dodaj pozycję do faktury, rozpocznij wpisywanie nazwy:<br>
                        Aby zobaczyć wszystkie towary, kliknij <a href=\"";
        // line 22
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("items_list");
        echo "\" target=\"_blank\">tutaj</a> ( otworzy się osobne okno ).
                    </div>

                    <div class=\"input-group input-group\">
                        <div class=\"input-group-prepend\">
                            <span class=\"input-group-text\" id=\"inputGroup-sizing\">nazwa towaru:</span>
                        </div>
                        <input type=\"text\"
                               id=\"lookfor\"
                               class=\"form-control\"
                               aria-describedby=\"inputGroup-sizing-sm\"
                               ng-model=\"lookfor\"
                               ng-change=\"myFunc()\"
                        >
                    </div>
                </div>
            </div>

            ";
        // line 42
        echo "
                <div ng-if=\"item_list.length>0 && item_list.length< 10\">
            ";
        echo "
                    <ul class=\"list-group\">
                        <li class=\"list-group-item\" ng-repeat=\"item in item_list\">

                            <a href=\"";
        // line 46
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("invoice_add_item_choice", ["invoice_id" => twig_get_attribute($this->env, $this->source, (isset($context["invoice"]) || array_key_exists("invoice", $context) ? $context["invoice"] : (function () { throw new RuntimeError('Variable "invoice" does not exist.', 46, $this->source); })()), "id", [], "any", false, false, false, 46)]), "html", null, true);
        echo "/";
        // line 48
        echo "{{ item[0] }}/\">
                                <h3><span class=\"badge badge-info\">{{ item[1] }}</span></h3>
                            </a>";
        echo "
                        </li>
                    </ul>
                </div>
        </div> <!-- container -->
    </div> <!-- AngularJS -->
    <br>

    <script type=\"text/javascript\">
        var angular_url = '";
        // line 57
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\HttpFoundationExtension']->generateAbsoluteUrl($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("angular_url")), "html", null, true);
        echo "';
    </script>

    <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\HttpFoundationExtension']->generateAbsoluteUrl($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/mangular_item.js")), "html", null, true);
        echo "\" type=\"text/javascript\"></script>

    ";
        // line 63
        echo "    ";
        if ((isset($context["invoices_items_richer"]) || array_key_exists("invoices_items_richer", $context) ? $context["invoices_items_richer"] : (function () { throw new RuntimeError('Variable "invoices_items_richer" does not exist.', 63, $this->source); })())) {
            // line 64
            echo "
        <table class=\"table\">

            ";
            // line 67
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["invoices_items_richer"]) || array_key_exists("invoices_items_richer", $context) ? $context["invoices_items_richer"] : (function () { throw new RuntimeError('Variable "invoices_items_richer" does not exist.', 67, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["invoice_item"]) {
                // line 68
                echo "                <tr>
                    <td>";
                // line 69
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 69), "html", null, true);
                echo "</td>
                    <td style=\"width:30%\" colspan=\"3\"><h4><span class=\"badge badge-dark\">";
                // line 70
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_item"], "name", [], "any", false, false, false, 70), "html", null, true);
                echo "</span></h4></td>
                    <td>
                        <a href=\"";
                // line 72
                echo "\">
                            <ion-icon ios=\"ios-trash\" md=\"md-trash\" style=\"font-size: 32px;\"></ion-icon>
                        </a>
                    </td>
                    <td style=\"text-align:right;\">";
                // line 76
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_item"], "items_number", [], "any", false, false, false, 76), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_item"], "jm", [], "any", false, false, false, 76), "html", null, true);
                echo "</td>
                </tr>

            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['invoice_item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 80
            echo "
        </table>


        <br><br><br>

    ";
        } else {
            // line 87
            echo "        <div class=\"alert alert-info\" role=\"alert\">
            faktura nie zawiera żadnych pozycji
        </div>
    ";
        }
        // line 91
        echo "    ";
        // line 92
        echo "

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 96
    public function block_base_form_main_lower_buttons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_lower_buttons"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_lower_buttons"));

        // line 97
        echo "
    <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "invoices/invoice_add_item_choice.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  243 => 97,  233 => 96,  221 => 92,  219 => 91,  213 => 87,  204 => 80,  184 => 76,  178 => 72,  173 => 70,  169 => 69,  166 => 68,  149 => 67,  144 => 64,  141 => 63,  136 => 60,  130 => 57,  116 => 48,  113 => 46,  104 => 42,  83 => 22,  72 => 13,  69 => 11,  59 => 10,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'invoices/invoice_add_item_choice.html.twig' #}

{% extends 'invoices/invoice_edit_common_pure.html.twig' %}

{# comment %}
    edycja faktury, wybieranie przedmiotu do dodania
{% endcomment #}


{% block base_left_part_for_item_select %}

    {# ------------------------------------ usługi/towary ------------------------------------- #}

    <div ng-app=\"myApp\" ng-controller=\"custCtrl\">
        <div class=\"container\">

            <div class=\"row\">
                <div class=\"col\">

                    <div class=\"alert alert-info\" role=\"alert\">
                        Dodaj pozycję do faktury, rozpocznij wpisywanie nazwy:<br>
                        Aby zobaczyć wszystkie towary, kliknij <a href=\"{{ path('items_list') }}\" target=\"_blank\">tutaj</a> ( otworzy się osobne okno ).
                    </div>

                    <div class=\"input-group input-group\">
                        <div class=\"input-group-prepend\">
                            <span class=\"input-group-text\" id=\"inputGroup-sizing\">nazwa towaru:</span>
                        </div>
                        <input type=\"text\"
                               id=\"lookfor\"
                               class=\"form-control\"
                               aria-describedby=\"inputGroup-sizing-sm\"
                               ng-model=\"lookfor\"
                               ng-change=\"myFunc()\"
                        >
                    </div>
                </div>
            </div>

            {% verbatim %}
                <div ng-if=\"item_list.length>0 && item_list.length< 10\">
            {% endverbatim %}
                    <ul class=\"list-group\">
                        <li class=\"list-group-item\" ng-repeat=\"item in item_list\">

                            <a href=\"{{ path('invoice_add_item_choice', {invoice_id:invoice.id}) }}/{% verbatim %}{{ item[0] }}/\">
                                <h3><span class=\"badge badge-info\">{{ item[1] }}</span></h3>
                            </a>{% endverbatim %}
                        </li>
                    </ul>
                </div>
        </div> <!-- container -->
    </div> <!-- AngularJS -->
    <br>

    <script type=\"text/javascript\">
        var angular_url = '{{ absolute_url(path('angular_url')) }}';
    </script>

    <script src=\"{{ absolute_url(asset('js/mangular_item.js')) }}\" type=\"text/javascript\"></script>

    {# --------------------------------------------------------------------------------- #}
    {% if invoices_items_richer %}

        <table class=\"table\">

            {% for invoice_item in invoices_items_richer %}
                <tr>
                    <td>{{ loop.index }}</td>
                    <td style=\"width:30%\" colspan=\"3\"><h4><span class=\"badge badge-dark\">{{ invoice_item.name }}</span></h4></td>
                    <td>
                        <a href=\"{# url 'invoice_del_item' invoice.id invoice_item.id invoice_item.iid #}\">
                            <ion-icon ios=\"ios-trash\" md=\"md-trash\" style=\"font-size: 32px;\"></ion-icon>
                        </a>
                    </td>
                    <td style=\"text-align:right;\">{{ invoice_item.items_number }} {{ invoice_item.jm }}</td>
                </tr>

            {% endfor %}

        </table>


        <br><br><br>

    {% else %}
        <div class=\"alert alert-info\" role=\"alert\">
            faktura nie zawiera żadnych pozycji
        </div>
    {% endif %}
    {# --------------------------------------------------------------------------------- #}


{% endblock %}

{% block base_form_main_lower_buttons %}

    <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>

{% endblock %}
", "invoices/invoice_add_item_choice.html.twig", "/home/wiks/Dokumenty/projects/iai_task/php/iai_invoice/templates/invoices/invoice_add_item_choice.html.twig");
    }
}
