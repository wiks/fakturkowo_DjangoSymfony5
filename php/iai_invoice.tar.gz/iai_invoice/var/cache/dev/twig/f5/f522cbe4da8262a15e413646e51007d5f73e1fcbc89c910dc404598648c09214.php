<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* items/items_list.html.twig */
class __TwigTemplate_50719ba12ec1d27f5446746638b88d070af30e45fdb7d90383bee99edfb838b8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'base_nav_main_div' => [$this, 'block_base_nav_main_div'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "base/base_nonav.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "items/items_list.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "items/items_list.html.twig"));

        $this->parent = $this->loadTemplate("base/base_nonav.html.twig", "items/items_list.html.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 11
    public function block_base_nav_main_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_main_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_main_div"));

        // line 12
        echo "
    <form action=\"\" method=\"post\">
        <input type=\"hidden\" name=\"token\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("itemslist"), "html", null, true);
        echo "\"/>

        <div class=\"alert alert-info\" role=\"alert\">
            Towary
        </div>

        ";
        // line 20
        if ((((isset($context["items_list"]) || array_key_exists("items_list", $context))) ? (_twig_default_filter((isset($context["items_list"]) || array_key_exists("items_list", $context) ? $context["items_list"] : (function () { throw new RuntimeError('Variable "items_list" does not exist.', 20, $this->source); })()))) : (""))) {
            // line 21
            echo "            <table class=\"table\">
                <tr>
                    <th>nazwa</th>
                    <th>cena netto</th>
                    <th>jm</th>
                    <th>vat</th>
                </tr>
                ";
            // line 28
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["items_list"]) || array_key_exists("items_list", $context) ? $context["items_list"] : (function () { throw new RuntimeError('Variable "items_list" does not exist.', 28, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["item_one"]) {
                // line 29
                echo "                    <tr>
                        <td style=\"width:55%\">";
                // line 30
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item_one"], "name", [], "any", false, false, false, 30), "html", null, true);
                echo "</td>
                        <td style=\"width:20%\">";
                // line 31
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item_one"], "priceNetto", [], "any", false, false, false, 31), "html", null, true);
                echo " PLN</td>
                        <td style=\"width:10%\">";
                // line 32
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item_one"], "jm", [], "any", false, false, false, 32), "name", [], "any", false, false, false, 32), "html", null, true);
                echo "</td>
                        <td>";
                // line 33
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item_one"], "vat", [], "any", false, false, false, 33), "percent", [], "any", false, false, false, 33), "html", null, true);
                echo " %</td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item_one'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 36
            echo "
                ";
            // line 38
            echo "                ";
            // line 47
            echo "            </table>

        ";
        } else {
            // line 50
            echo "            <div class=\"alert alert-warning\" role=\"alert\">
                towarów brak - przyjęcie towaru proponuje
            </div>
        ";
        }
        // line 54
        echo "
        <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>
    </form>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "items/items_list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  136 => 54,  130 => 50,  125 => 47,  123 => 38,  120 => 36,  111 => 33,  107 => 32,  103 => 31,  99 => 30,  96 => 29,  92 => 28,  83 => 21,  81 => 20,  72 => 14,  68 => 12,  58 => 11,  35 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'items/items_list.html.twig' #}

{% extends \"base/base_nonav.html.twig\" %}

{# comment %}
    lista towarów
{% endcomment #}

{# load proper_paginate #}

{% block base_nav_main_div %}

    <form action=\"\" method=\"post\">
        <input type=\"hidden\" name=\"token\" value=\"{{ csrf_token('itemslist') }}\"/>

        <div class=\"alert alert-info\" role=\"alert\">
            Towary
        </div>

        {% if items_list|default %}
            <table class=\"table\">
                <tr>
                    <th>nazwa</th>
                    <th>cena netto</th>
                    <th>jm</th>
                    <th>vat</th>
                </tr>
                {% for item_one in items_list %}
                    <tr>
                        <td style=\"width:55%\">{{ item_one.name }}</td>
                        <td style=\"width:20%\">{{ item_one.priceNetto }} PLN</td>
                        <td style=\"width:10%\">{{ item_one.jm.name }}</td>
                        <td>{{ item_one.vat.percent }} %</td>
                    </tr>
                {% endfor %}

                {#<!-- sprawdzam czy jest paginator -->#}
                {# if paginator %}
                    <tr>
                        <td colspan=\"4\">
                            {% with corected_pagination as page_obj %}
                                {% include \"base/pagination_buttons.html.twig\" %}
                            {% endwith %}
                        </td>
                    </tr>
                {% endif #}
            </table>

        {% else %}
            <div class=\"alert alert-warning\" role=\"alert\">
                towarów brak - przyjęcie towaru proponuje
            </div>
        {% endif %}

        <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>
    </form>

{% endblock %}
", "items/items_list.html.twig", "/home/wiks/Pulpit/iai_task/php/iai_invoice/templates/items/items_list.html.twig");
    }
}
