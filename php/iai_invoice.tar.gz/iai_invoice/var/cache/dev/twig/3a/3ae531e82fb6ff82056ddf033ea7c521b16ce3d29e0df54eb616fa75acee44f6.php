<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* invoices/invoice_edit_add_item.html.twig */
class __TwigTemplate_33b50df94f7c3fd36b640e34e086deca9e8dbe0bda12185b554d7f8494012b7e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'base_left_part_for_item_select' => [$this, 'block_base_left_part_for_item_select'],
            'base_form_main_lower_buttons' => [$this, 'block_base_form_main_lower_buttons'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "invoices/invoice_edit_common_pure.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_edit_add_item.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_edit_add_item.html.twig"));

        $this->parent = $this->loadTemplate("invoices/invoice_edit_common_pure.html.twig", "invoices/invoice_edit_add_item.html.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 9
    public function block_base_left_part_for_item_select($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_left_part_for_item_select"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_left_part_for_item_select"));

        // line 10
        echo "
    ";
        // line 12
        echo "
    <div class=\"alert alert-info\" role=\"alert\">
        Dodawanie wybranego towaru do faktury:<br>
    </div>

    <div class=\"alert alert-info\" role=\"alert\">
        <h3><span class=\"badge badge-light\">";
        // line 18
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 18, $this->source); })()), "name", [], "any", false, false, false, 18), "html", null, true);
        echo "</span></h3>
        cena netto: ";
        // line 19
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 19, $this->source); })()), "priceNetto", [], "any", false, false, false, 19), "html", null, true);
        echo " PLN, za 1 ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 19, $this->source); })()), "jm", [], "any", false, false, false, 19), "name", [], "any", false, false, false, 19), "html", null, true);
        echo " [VAT: ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 19, $this->source); })()), "vat", [], "any", false, false, false, 19), "percent", [], "any", false, false, false, 19), "html", null, true);
        echo "% ]
    </div>

    <div class=\"alert alert-info\" role=\"alert\">
        podaj ile ";
        // line 23
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["item"]) || array_key_exists("item", $context) ? $context["item"] : (function () { throw new RuntimeError('Variable "item" does not exist.', 23, $this->source); })()), "jm", [], "any", false, false, false, 23), "name", [], "any", false, false, false, 23), "html", null, true);
        echo ":<br>
        <input type=\"text\"
               id=\"item_amount\"
               name=\"item_amount\"
               class=\"form-control\"
               aria-describedby=\"inputGroup-sizing-sm\">
    </div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 33
    public function block_base_form_main_lower_buttons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_lower_buttons"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_lower_buttons"));

        // line 34
        echo "
    <button type=\"submit\" name=\"action\" value=\"OK\" class=\"btn btn-primary btn\">Zapisz</button>
    <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "invoices/invoice_edit_add_item.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 34,  114 => 33,  95 => 23,  84 => 19,  80 => 18,  72 => 12,  69 => 10,  59 => 9,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'invoices/invoice_edit_add_item.html.twig' #}

{% extends 'invoices/invoice_edit_common_pure.html.twig' %}

{# comment %}
    edycja faktury, wybieranie przedmiotu do dodania
{% endcomment #}

{% block base_left_part_for_item_select %}

    {# ------------------------------------ usługi/towary ------------------------------------- #}

    <div class=\"alert alert-info\" role=\"alert\">
        Dodawanie wybranego towaru do faktury:<br>
    </div>

    <div class=\"alert alert-info\" role=\"alert\">
        <h3><span class=\"badge badge-light\">{{ item.name }}</span></h3>
        cena netto: {{ item.priceNetto }} PLN, za 1 {{ item.jm.name }} [VAT: {{ item.vat.percent }}% ]
    </div>

    <div class=\"alert alert-info\" role=\"alert\">
        podaj ile {{ item.jm.name }}:<br>
        <input type=\"text\"
               id=\"item_amount\"
               name=\"item_amount\"
               class=\"form-control\"
               aria-describedby=\"inputGroup-sizing-sm\">
    </div>

{% endblock %}

{% block base_form_main_lower_buttons %}

    <button type=\"submit\" name=\"action\" value=\"OK\" class=\"btn btn-primary btn\">Zapisz</button>
    <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>

{% endblock %}
", "invoices/invoice_edit_add_item.html.twig", "/home/wiks/Dokumenty/projects/iai_task/php/iai_invoice/templates/invoices/invoice_edit_add_item.html.twig");
    }
}
