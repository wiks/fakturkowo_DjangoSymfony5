<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* customers/firm_show.html.twig */
class __TwigTemplate_faba882404834a39fc7e5a592db2eb9edcfc65531db226189e325f9b12522bdc extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'base_nav_main_div' => [$this, 'block_base_nav_main_div'],
            'base_form_main_head_div' => [$this, 'block_base_form_main_head_div'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "base/base_nonav.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "customers/firm_show.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "customers/firm_show.html.twig"));

        $this->parent = $this->loadTemplate("base/base_nonav.html.twig", "customers/firm_show.html.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 10
    public function block_base_nav_main_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_main_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_main_div"));

        // line 11
        echo "
    ";
        // line 12
        $this->displayBlock('base_form_main_head_div', $context, $blocks);
        // line 13
        echo "
    ";
        // line 14
        if ((isset($context["firm_data_obj"]) || array_key_exists("firm_data_obj", $context) ? $context["firm_data_obj"] : (function () { throw new RuntimeError('Variable "firm_data_obj" does not exist.', 14, $this->source); })())) {
            // line 15
            echo "
        <div class=\"container\">

            <div class=\"row\">
                <div class=\"col-sm\">
                    <h1>
                        <span class=\"badge badge-dark\">";
            // line 21
            echo twig_escape_filter($this->env, (isset($context["firmName"]) || array_key_exists("firmName", $context) ? $context["firmName"] : (function () { throw new RuntimeError('Variable "firmName" does not exist.', 21, $this->source); })()), "html", null, true);
            echo "</span>
                    </h1>
                </div>
            </div>

            <div class=\"row\">
                <div class=\"col-sm\">

                    <div class=\"form-group\">
                        <label for=\"firmAdres1\">adres</label>
                        <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres1\" name=\"firmAdres1\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, (isset($context["firmAdres1"]) || array_key_exists("firmAdres1", $context) ? $context["firmAdres1"] : (function () { throw new RuntimeError('Variable "firmAdres1" does not exist.', 31, $this->source); })()), "html", null, true);
            echo "\"
                               aria-describedby=\"firmAdres1Help\" disabled>
                        ";
            // line 33
            if ((((isset($context["firmAdres2"]) || array_key_exists("firmAdres2", $context))) ? (_twig_default_filter((isset($context["firmAdres2"]) || array_key_exists("firmAdres2", $context) ? $context["firmAdres2"] : (function () { throw new RuntimeError('Variable "firmAdres2" does not exist.', 33, $this->source); })()))) : (""))) {
                // line 34
                echo "                            <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres2\" name=\"firmAdres2\" value=\"";
                echo twig_escape_filter($this->env, (isset($context["firmAdres2"]) || array_key_exists("firmAdres2", $context) ? $context["firmAdres2"] : (function () { throw new RuntimeError('Variable "firmAdres2" does not exist.', 34, $this->source); })()), "html", null, true);
                echo "\"
                                   aria-describedby=\"firmAdres1Help\" disabled>
                        ";
            }
            // line 37
            echo "                        ";
            if ((((isset($context["firmAdres3"]) || array_key_exists("firmAdres3", $context))) ? (_twig_default_filter((isset($context["firmAdres3"]) || array_key_exists("firmAdres3", $context) ? $context["firmAdres3"] : (function () { throw new RuntimeError('Variable "firmAdres3" does not exist.', 37, $this->source); })()))) : (""))) {
                // line 38
                echo "                            <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres3\" name=\"firmAdres3\" value=\"";
                echo twig_escape_filter($this->env, (isset($context["firmAdres3"]) || array_key_exists("firmAdres3", $context) ? $context["firmAdres3"] : (function () { throw new RuntimeError('Variable "firmAdres3" does not exist.', 38, $this->source); })()), "html", null, true);
                echo "\"
                                   aria-describedby=\"firmAdres1Help\" disabled>
                        ";
            }
            // line 41
            echo "                        ";
            if ((((isset($context["firmAdres4"]) || array_key_exists("firmAdres4", $context))) ? (_twig_default_filter((isset($context["firmAdres4"]) || array_key_exists("firmAdres4", $context) ? $context["firmAdres4"] : (function () { throw new RuntimeError('Variable "firmAdres4" does not exist.', 41, $this->source); })()))) : (""))) {
                // line 42
                echo "                            <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres4\" name=\"firmAdres4\" value=\"";
                echo twig_escape_filter($this->env, (isset($context["firmAdres4"]) || array_key_exists("firmAdres4", $context) ? $context["firmAdres4"] : (function () { throw new RuntimeError('Variable "firmAdres4" does not exist.', 42, $this->source); })()), "html", null, true);
                echo "\"
                                   aria-describedby=\"firmAdres1Help\" disabled>
                        ";
            }
            // line 45
            echo "                        ";
            if ((((isset($context["firmAdres5"]) || array_key_exists("firmAdres5", $context))) ? (_twig_default_filter((isset($context["firmAdres5"]) || array_key_exists("firmAdres5", $context) ? $context["firmAdres5"] : (function () { throw new RuntimeError('Variable "firmAdres5" does not exist.', 45, $this->source); })()))) : (""))) {
                // line 46
                echo "                            <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres5\" name=\"firmAdres5\" value=\"";
                echo twig_escape_filter($this->env, (isset($context["firmAdres5"]) || array_key_exists("firmAdres5", $context) ? $context["firmAdres5"] : (function () { throw new RuntimeError('Variable "firmAdres5" does not exist.', 46, $this->source); })()), "html", null, true);
                echo "\"
                                   aria-describedby=\"firmAdres1Help\" disabled>
                        ";
            }
            // line 49
            echo "                    </div>

                    ";
            // line 51
            if ((((isset($context["mInputEmail"]) || array_key_exists("mInputEmail", $context))) ? (_twig_default_filter((isset($context["mInputEmail"]) || array_key_exists("mInputEmail", $context) ? $context["mInputEmail"] : (function () { throw new RuntimeError('Variable "mInputEmail" does not exist.', 51, $this->source); })()))) : (""))) {
                // line 52
                echo "                        <div class=\"form-group\">
                            <label for=\"mInputEmail\">email</label>
                            <input type=\"email\" class=\"form-control mInputEmail\" id=\"mInputEmail\" name=\"mInputEmail\" value=\"";
                // line 54
                echo twig_escape_filter($this->env, (isset($context["mInputEmail"]) || array_key_exists("mInputEmail", $context) ? $context["mInputEmail"] : (function () { throw new RuntimeError('Variable "mInputEmail" does not exist.', 54, $this->source); })()), "html", null, true);
                echo "\"
                                   aria-describedby=\"emailHelp\" disabled>
                        </div>
                    ";
            }
            // line 58
            echo "
                </div>
                <div class=\"col-sm\">

                    ";
            // line 62
            if ((((isset($context["firmNip"]) || array_key_exists("firmNip", $context))) ? (_twig_default_filter((isset($context["firmNip"]) || array_key_exists("firmNip", $context) ? $context["firmNip"] : (function () { throw new RuntimeError('Variable "firmNip" does not exist.', 62, $this->source); })()))) : (""))) {
                // line 63
                echo "                        <div class=\"form-group\">
                            <label for=\"firmNip\">NIP</label>
                            <input type=\"text\" class=\"form-control firmNip\" id=\"firmNip\" name=\"firmNip\" value=\"";
                // line 65
                echo twig_escape_filter($this->env, (isset($context["firmNip"]) || array_key_exists("firmNip", $context) ? $context["firmNip"] : (function () { throw new RuntimeError('Variable "firmNip" does not exist.', 65, $this->source); })()), "html", null, true);
                echo "\"
                                   aria-describedby=\"firmNipHelp\" disabled>
                        </div>
                    ";
            }
            // line 69
            echo "
                    ";
            // line 70
            if ((((isset($context["firmRegon"]) || array_key_exists("firmRegon", $context))) ? (_twig_default_filter((isset($context["firmRegon"]) || array_key_exists("firmRegon", $context) ? $context["firmRegon"] : (function () { throw new RuntimeError('Variable "firmRegon" does not exist.', 70, $this->source); })()))) : (""))) {
                // line 71
                echo "                        <div class=\"form-group\">
                            <label for=\"firmRegon\">REGON</label>
                            <input type=\"text\" class=\"form-control firmRegon\" id=\"firmRegon\" name=\"firmRegon\" value=\"";
                // line 73
                echo twig_escape_filter($this->env, (isset($context["firmRegon"]) || array_key_exists("firmRegon", $context) ? $context["firmRegon"] : (function () { throw new RuntimeError('Variable "firmRegon" does not exist.', 73, $this->source); })()), "html", null, true);
                echo "\"
                                   aria-describedby=\"firmNipHelp\" disabled>
                        </div>
                    ";
            }
            // line 77
            echo "
                    ";
            // line 78
            if ((((isset($context["firmPesel"]) || array_key_exists("firmPesel", $context))) ? (_twig_default_filter((isset($context["firmPesel"]) || array_key_exists("firmPesel", $context) ? $context["firmPesel"] : (function () { throw new RuntimeError('Variable "firmPesel" does not exist.', 78, $this->source); })()))) : (""))) {
                // line 79
                echo "                        <div class=\"form-group\">
                            <label for=\"firmPesel\">PESEL</label>
                            <input type=\"text\" class=\"form-control firmPesel\" id=\"firmPesel\" name=\"firmPesel\" value=\"";
                // line 81
                echo twig_escape_filter($this->env, (isset($context["firmPesel"]) || array_key_exists("firmPesel", $context) ? $context["firmPesel"] : (function () { throw new RuntimeError('Variable "firmPesel" does not exist.', 81, $this->source); })()), "html", null, true);
                echo "\"
                                   aria-describedby=\"firmNipHelp\" disabled>
                        </div>
                    ";
            }
            // line 85
            echo "
                    <div class=\"form-group\">
                        <label for=\"firmAccount1\">bank, numer konta</label>
                        <input type=\"text\" class=\"form-control firmAccount\" id=\"firmAccount1\" name=\"firmAccount1\" value=\"";
            // line 88
            echo twig_escape_filter($this->env, (isset($context["firmAccount1"]) || array_key_exists("firmAccount1", $context) ? $context["firmAccount1"] : (function () { throw new RuntimeError('Variable "firmAccount1" does not exist.', 88, $this->source); })()), "html", null, true);
            echo "\"
                               aria-describedby=\"firmAccount1Help\" disabled>

                        ";
            // line 91
            if ((((isset($context["firmAccount2"]) || array_key_exists("firmAccount2", $context))) ? (_twig_default_filter((isset($context["firmAccount2"]) || array_key_exists("firmAccount2", $context) ? $context["firmAccount2"] : (function () { throw new RuntimeError('Variable "firmAccount2" does not exist.', 91, $this->source); })()))) : (""))) {
                // line 92
                echo "                            <input type=\"text\" class=\"form-control firmAccount\" id=\"firmAccount2\" name=\"firmAccount2\" value=\"";
                echo twig_escape_filter($this->env, (isset($context["firmAccount2"]) || array_key_exists("firmAccount2", $context) ? $context["firmAccount2"] : (function () { throw new RuntimeError('Variable "firmAccount2" does not exist.', 92, $this->source); })()), "html", null, true);
                echo "\"
                                   aria-describedby=\"firmAccount2Help\" disabled>
                        ";
            }
            // line 95
            echo "                    </div>

                </div>
            </div>

        </div>

        <button type=\"submit\" name=\"action\" value=\"create_edit\" class=\"btn btn-primary btn\">edytuj</button>

    ";
        } else {
            // line 105
            echo "
        <button type=\"submit\" name=\"action\" value=\"create_edit\" class=\"btn btn-primary btn\">utwórz</button>

    ";
        }
        // line 109
        echo "
    <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 12
    public function block_base_form_main_head_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_head_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_head_div"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "customers/firm_show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  263 => 12,  250 => 109,  244 => 105,  232 => 95,  225 => 92,  223 => 91,  217 => 88,  212 => 85,  205 => 81,  201 => 79,  199 => 78,  196 => 77,  189 => 73,  185 => 71,  183 => 70,  180 => 69,  173 => 65,  169 => 63,  167 => 62,  161 => 58,  154 => 54,  150 => 52,  148 => 51,  144 => 49,  137 => 46,  134 => 45,  127 => 42,  124 => 41,  117 => 38,  114 => 37,  107 => 34,  105 => 33,  100 => 31,  87 => 21,  79 => 15,  77 => 14,  74 => 13,  72 => 12,  69 => 11,  59 => 10,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'customers/firm_show.html.twig' #}

{% extends \"base/base_nonav.html.twig\" %}

{# comment %}
    edycja danych własnych lub firmy klienta
{% endcomment #}


{% block base_nav_main_div %}

    {% block base_form_main_head_div %}{% endblock %}

    {% if firm_data_obj %}

        <div class=\"container\">

            <div class=\"row\">
                <div class=\"col-sm\">
                    <h1>
                        <span class=\"badge badge-dark\">{{ firmName }}</span>
                    </h1>
                </div>
            </div>

            <div class=\"row\">
                <div class=\"col-sm\">

                    <div class=\"form-group\">
                        <label for=\"firmAdres1\">adres</label>
                        <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres1\" name=\"firmAdres1\" value=\"{{ firmAdres1 }}\"
                               aria-describedby=\"firmAdres1Help\" disabled>
                        {% if firmAdres2|default %}
                            <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres2\" name=\"firmAdres2\" value=\"{{ firmAdres2 }}\"
                                   aria-describedby=\"firmAdres1Help\" disabled>
                        {% endif %}
                        {% if firmAdres3|default %}
                            <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres3\" name=\"firmAdres3\" value=\"{{ firmAdres3 }}\"
                                   aria-describedby=\"firmAdres1Help\" disabled>
                        {% endif %}
                        {% if firmAdres4|default %}
                            <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres4\" name=\"firmAdres4\" value=\"{{ firmAdres4 }}\"
                                   aria-describedby=\"firmAdres1Help\" disabled>
                        {% endif %}
                        {% if firmAdres5|default %}
                            <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres5\" name=\"firmAdres5\" value=\"{{ firmAdres5 }}\"
                                   aria-describedby=\"firmAdres1Help\" disabled>
                        {% endif %}
                    </div>

                    {% if mInputEmail|default %}
                        <div class=\"form-group\">
                            <label for=\"mInputEmail\">email</label>
                            <input type=\"email\" class=\"form-control mInputEmail\" id=\"mInputEmail\" name=\"mInputEmail\" value=\"{{ mInputEmail }}\"
                                   aria-describedby=\"emailHelp\" disabled>
                        </div>
                    {% endif %}

                </div>
                <div class=\"col-sm\">

                    {% if firmNip|default %}
                        <div class=\"form-group\">
                            <label for=\"firmNip\">NIP</label>
                            <input type=\"text\" class=\"form-control firmNip\" id=\"firmNip\" name=\"firmNip\" value=\"{{ firmNip }}\"
                                   aria-describedby=\"firmNipHelp\" disabled>
                        </div>
                    {% endif %}

                    {% if firmRegon|default %}
                        <div class=\"form-group\">
                            <label for=\"firmRegon\">REGON</label>
                            <input type=\"text\" class=\"form-control firmRegon\" id=\"firmRegon\" name=\"firmRegon\" value=\"{{ firmRegon }}\"
                                   aria-describedby=\"firmNipHelp\" disabled>
                        </div>
                    {% endif %}

                    {% if firmPesel|default %}
                        <div class=\"form-group\">
                            <label for=\"firmPesel\">PESEL</label>
                            <input type=\"text\" class=\"form-control firmPesel\" id=\"firmPesel\" name=\"firmPesel\" value=\"{{ firmPesel }}\"
                                   aria-describedby=\"firmNipHelp\" disabled>
                        </div>
                    {% endif %}

                    <div class=\"form-group\">
                        <label for=\"firmAccount1\">bank, numer konta</label>
                        <input type=\"text\" class=\"form-control firmAccount\" id=\"firmAccount1\" name=\"firmAccount1\" value=\"{{ firmAccount1 }}\"
                               aria-describedby=\"firmAccount1Help\" disabled>

                        {% if firmAccount2|default %}
                            <input type=\"text\" class=\"form-control firmAccount\" id=\"firmAccount2\" name=\"firmAccount2\" value=\"{{ firmAccount2 }}\"
                                   aria-describedby=\"firmAccount2Help\" disabled>
                        {% endif %}
                    </div>

                </div>
            </div>

        </div>

        <button type=\"submit\" name=\"action\" value=\"create_edit\" class=\"btn btn-primary btn\">edytuj</button>

    {% else %}

        <button type=\"submit\" name=\"action\" value=\"create_edit\" class=\"btn btn-primary btn\">utwórz</button>

    {% endif %}

    <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>

{% endblock %}
", "customers/firm_show.html.twig", "/home/wiks/Dokumenty/projects/iai_task/php/iai_invoice/templates/customers/firm_show.html.twig");
    }
}
