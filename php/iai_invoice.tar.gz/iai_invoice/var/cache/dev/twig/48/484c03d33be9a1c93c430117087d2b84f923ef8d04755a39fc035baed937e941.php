<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* items/items_list.html.twig */
class __TwigTemplate_2dc5b7110348ff0fe1c835a2fd31ae79973b1bb10efd5b1dbd78538ad9419b47 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'base_nav_main_div' => [$this, 'block_base_nav_main_div'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "base/base_nonav.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "items/items_list.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "items/items_list.html.twig"));

        $this->parent = $this->loadTemplate("base/base_nonav.html.twig", "items/items_list.html.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 11
    public function block_base_nav_main_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_main_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_main_div"));

        // line 12
        echo "
    <div class=\"alert alert-info\" role=\"alert\">
        Towary
    </div>

    ";
        // line 17
        if ((((isset($context["items_list"]) || array_key_exists("items_list", $context))) ? (_twig_default_filter((isset($context["items_list"]) || array_key_exists("items_list", $context) ? $context["items_list"] : (function () { throw new RuntimeError('Variable "items_list" does not exist.', 17, $this->source); })()))) : (""))) {
            // line 18
            echo "        <table class=\"table\">
            <tr>
                <th>nazwa</th>
                <th>cena netto</th>
                <th>jm</th>
                <th>vat</th>
            </tr>
            ";
            // line 25
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["items_list"]) || array_key_exists("items_list", $context) ? $context["items_list"] : (function () { throw new RuntimeError('Variable "items_list" does not exist.', 25, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["item_one"]) {
                // line 26
                echo "                <tr>
                    <td style=\"width:55%\">";
                // line 27
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item_one"], "name", [], "any", false, false, false, 27), "html", null, true);
                echo "</td>
                    <td style=\"width:20%\">";
                // line 28
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item_one"], "priceNetto", [], "any", false, false, false, 28), "html", null, true);
                echo " PLN</td>
                    <td style=\"width:10%\">";
                // line 29
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item_one"], "jm", [], "any", false, false, false, 29), "name", [], "any", false, false, false, 29), "html", null, true);
                echo "</td>
                    <td>";
                // line 30
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item_one"], "vat", [], "any", false, false, false, 30), "percent", [], "any", false, false, false, 30), "html", null, true);
                echo " %</td>
                </tr>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item_one'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 33
            echo "
            ";
            // line 35
            echo "            <tr>
                <td colspan=\"4\">
                    ";
            // line 37
            echo $this->extensions['Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension']->render($this->env, (isset($context["items_list"]) || array_key_exists("items_list", $context) ? $context["items_list"] : (function () { throw new RuntimeError('Variable "items_list" does not exist.', 37, $this->source); })()));
            echo " 
                </td>
            </tr>

        </table>

    ";
        } else {
            // line 44
            echo "        <div class=\"alert alert-warning\" role=\"alert\">
            towarów brak - przyjęcie towaru proponuje
        </div>
    ";
        }
        // line 48
        echo "
    <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "items/items_list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 48,  131 => 44,  121 => 37,  117 => 35,  114 => 33,  105 => 30,  101 => 29,  97 => 28,  93 => 27,  90 => 26,  86 => 25,  77 => 18,  75 => 17,  68 => 12,  58 => 11,  35 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'items/items_list.html.twig' #}

{% extends \"base/base_nonav.html.twig\" %}

{# comment %}
    lista towarów
{% endcomment #}

{# load proper_paginate #}

{% block base_nav_main_div %}

    <div class=\"alert alert-info\" role=\"alert\">
        Towary
    </div>

    {% if items_list|default %}
        <table class=\"table\">
            <tr>
                <th>nazwa</th>
                <th>cena netto</th>
                <th>jm</th>
                <th>vat</th>
            </tr>
            {% for item_one in items_list %}
                <tr>
                    <td style=\"width:55%\">{{ item_one.name }}</td>
                    <td style=\"width:20%\">{{ item_one.priceNetto }} PLN</td>
                    <td style=\"width:10%\">{{ item_one.jm.name }}</td>
                    <td>{{ item_one.vat.percent }} %</td>
                </tr>
            {% endfor %}

            {#<!-- sprawdzam czy jest paginator -->#}
            <tr>
                <td colspan=\"4\">
                    {{ knp_pagination_render(items_list) }} 
                </td>
            </tr>

        </table>

    {% else %}
        <div class=\"alert alert-warning\" role=\"alert\">
            towarów brak - przyjęcie towaru proponuje
        </div>
    {% endif %}

    <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>

{% endblock %}
", "items/items_list.html.twig", "/home/wiks/Dokumenty/projects/iai_task/php/iai_invoice/templates/items/items_list.html.twig");
    }
}
