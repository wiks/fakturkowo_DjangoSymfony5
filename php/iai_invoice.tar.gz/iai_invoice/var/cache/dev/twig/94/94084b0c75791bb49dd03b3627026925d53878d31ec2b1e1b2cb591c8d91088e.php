<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* invoices/invoice_edit_common.html.twig */
class __TwigTemplate_b27bf903c0f925739bf50ebaf6f1fc997ae97c47b7902cb3eddb7ddd782f8f03 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'base_form_main_left_div' => [$this, 'block_base_form_main_left_div'],
            'base_left_part_for_item_select' => [$this, 'block_base_left_part_for_item_select'],
            'base_form_main_right_div' => [$this, 'block_base_form_main_right_div'],
            'base_form_main_lower_buttons' => [$this, 'block_base_form_main_lower_buttons'],
            'base_nav_footer_scripts' => [$this, 'block_base_nav_footer_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "base/base_form_twocolumns_mid.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_edit_common.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_edit_common.html.twig"));

        $this->parent = $this->loadTemplate("base/base_form_twocolumns_mid.html.twig", "invoices/invoice_edit_common.html.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 10
    public function block_base_form_main_left_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_left_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_left_div"));

        // line 11
        echo "
    ";
        // line 13
        echo "    Sprzedawca:<br>
    <h2><span class=\"badge badge-dark\">";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["seller"]) || array_key_exists("seller", $context) ? $context["seller"] : (function () { throw new RuntimeError('Variable "seller" does not exist.', 14, $this->source); })()), "fname", [], "any", false, false, false, 14), "html", null, true);
        echo "</span></h2>
    <br><br>
    ";
        // line 17
        echo "

    ";
        // line 20
        echo "    ";
        $this->displayBlock('base_left_part_for_item_select', $context, $blocks);
        // line 21
        echo "    ";
        // line 22
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 20
    public function block_base_left_part_for_item_select($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_left_part_for_item_select"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_left_part_for_item_select"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 25
    public function block_base_form_main_right_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_right_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_right_div"));

        // line 26
        echo "
    ";
        // line 28
        echo "    Nabywca:<br>
    <h2><span class=\"badge badge-dark\">";
        // line 29
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["customer"]) || array_key_exists("customer", $context) ? $context["customer"] : (function () { throw new RuntimeError('Variable "customer" does not exist.', 29, $this->source); })()), "fname", [], "any", false, false, false, 29), "html", null, true);
        echo "</span></h2>
    <br><br>
    ";
        // line 32
        echo "

    ";
        // line 35
        echo "    <div class=\"form-group\">
        <label for=\"fNr\">numer faktury</label>
        <input type=\"text\" class=\"form-control fNr\" id=\"fNr\" name=\"fNr\" value=\"";
        // line 37
        echo twig_escape_filter($this->env, (isset($context["fNr"]) || array_key_exists("fNr", $context) ? $context["fNr"] : (function () { throw new RuntimeError('Variable "fNr" does not exist.', 37, $this->source); })()), "html", null, true);
        echo "\"
               aria-describedby=\"fNrHelp\" placeholder=\"numer faktury\">
        <small id=\"sfNr\" class=\"form-text text-muted\">numer faktury -wymagany</small>
    </div>

    <table style=\"width:100%;\">
        <tr>
            <td style=\"width:50%;\">
    <div class=\"form-group\">
        <label>faktura z dnia</label>
        <input type=\"date\" name=\"dt_created\" max=\"3000-12-31\" value=\"";
        // line 47
        echo twig_escape_filter($this->env, (isset($context["dt_created"]) || array_key_exists("dt_created", $context) ? $context["dt_created"] : (function () { throw new RuntimeError('Variable "dt_created" does not exist.', 47, $this->source); })()), "html", null, true);
        echo "\"
            min=\"1000-01-01\" class=\"form-control\">
    </div>
            </td>
            <td>
    <div class=\"form-group\">
        <label>termin płatności</label>
        <input type=\"date\" name=\"dt_pait_to\" max=\"3000-12-31\" value=\"";
        // line 54
        echo twig_escape_filter($this->env, (isset($context["dt_pait_to"]) || array_key_exists("dt_pait_to", $context) ? $context["dt_pait_to"] : (function () { throw new RuntimeError('Variable "dt_pait_to" does not exist.', 54, $this->source); })()), "html", null, true);
        echo "\"
            min=\"1000-01-01\" class=\"form-control\">
    </div>
            </td>
        </tr>
    </table>

    <div class=\"form-group\">
        <label>data dostarczenia usługi</label>
        <input type=\"date\" name=\"dt_delivery\" max=\"3000-12-31\" value=\"";
        // line 63
        echo twig_escape_filter($this->env, (isset($context["dt_delivery"]) || array_key_exists("dt_delivery", $context) ? $context["dt_delivery"] : (function () { throw new RuntimeError('Variable "dt_delivery" does not exist.', 63, $this->source); })()), "html", null, true);
        echo "\"
            min=\"1000-01-01\" class=\"form-control\">
    </div>


    <div class=\"form-group\">
        <label for=\"person_auth_name\">osoba upoważniona</label>
        <input type=\"text\" class=\"form-control person_auth_name\" id=\"person_auth_name\" name=\"person_auth_name\" value=\"";
        // line 70
        echo twig_escape_filter($this->env, (isset($context["person_auth_name"]) || array_key_exists("person_auth_name", $context) ? $context["person_auth_name"] : (function () { throw new RuntimeError('Variable "person_auth_name" does not exist.', 70, $this->source); })()), "html", null, true);
        echo "\"
               aria-describedby=\"nameHelp\" placeholder=\"\">
        <small id=\"sperson_auth_name\" class=\"form-text text-muted\">osoba upoważniona do wystawienia faktury</small>
    </div>
    ";
        // line 75
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 79
    public function block_base_form_main_lower_buttons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_lower_buttons"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_lower_buttons"));

        // line 80
        echo "
    <button type=\"submit\" name=\"action\" value=\"OK\" class=\"btn btn-primary btn\">Zapisz</button>
    <button type=\"submit\" name=\"action\" value=\"delete\" class=\"btn btn-warning btn\">Usuń</button>
    <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 87
    public function block_base_nav_footer_scripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_footer_scripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_footer_scripts"));

        // line 88
        echo "
    <script>

        /** odszukaj element input, wyciągnij z nich funkcyjne klasy nez duplikacji
         *  dla każdej z nich sprawdź, czy jest na liście błędów,
         *  jeśli tak -dodaj klasę error, jeśli nie usuń klasę error
         */
        function do_with_error_class() {

            var input_list = document.getElementsByTagName('input');

            // pobieram wszystkie klasy:
            var form_input_class_list = [];
            for(var i=0;i<input_list.length;i++) {
                //input_list[i].classList.contains(\"active\");
                for(var j=0;j<input_list[i].classList.length;j++) {
                    var one_class = input_list[i].classList[j];
                    if((one_class != 'form-control') && (form_input_class_list.indexOf(one_class) < 0)) {
                        form_input_class_list.push(one_class);
                    }
                }
            }

            // to do wyświetlenia tylko
            var errors_message_list = [];
            ";
        // line 113
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((((isset($context["errors_message_list"]) || array_key_exists("errors_message_list", $context))) ? (_twig_default_filter((isset($context["errors_message_list"]) || array_key_exists("errors_message_list", $context) ? $context["errors_message_list"] : (function () { throw new RuntimeError('Variable "errors_message_list" does not exist.', 113, $this->source); })()))) : ("")));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 114
            echo "                errors_message_list.push('";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "');
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 116
        echo "
            var errors_message_redclass_list = [];
            ";
        // line 118
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((((isset($context["errors_message_redclass_list"]) || array_key_exists("errors_message_redclass_list", $context))) ? (_twig_default_filter((isset($context["errors_message_redclass_list"]) || array_key_exists("errors_message_redclass_list", $context) ? $context["errors_message_redclass_list"] : (function () { throw new RuntimeError('Variable "errors_message_redclass_list" does not exist.', 118, $this->source); })()))) : ("")));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 119
            echo "                errors_message_redclass_list.push('";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "');
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 121
        echo "
            // dla każdej z klas pobieram elementy i dodaję lub usuwam klasę error_input
            for(var k=0;k<form_input_class_list.length;k++) {
                // klasa, którą sprawdzam teraz:
                var one_class = form_input_class_list[k];
                // pobieram wszystkie elementy z tą klasą:
                var one_class_elements_list = document.getElementsByClassName(one_class);
                //console.log('elementy z klasą: \"' + one_class + '\" --> szt: ' + one_class_elements_list.length)
                // dla każdego z nich:
                for(var l=0;l<one_class_elements_list.length;l++) {
                    // jeśli ta klasa jest w błędnych -> zaznaczam error
                    if(  errors_message_redclass_list.indexOf(one_class) >= 0 ) {
                        //console.log('powinien być error')
                        if(!one_class_elements_list[l].classList.contains(\"error\")) {
                            //console.log('nie zawiera, więc dodaję error')
                            one_class_elements_list[l].classList.add(\"error\");
                        }
                    }else{
                        //console.log('NIE powinno być erroru')
                        if(one_class_elements_list[l].classList.contains(\"error\")) {
                            //console.log('zawiera, więc usuwam error')
                            one_class_elements_list[l].classList.remove(\"error\");
                        }
                    }
                }
            }
        }

        do_with_error_class();

    </script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "invoices/invoice_edit_common.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  305 => 121,  296 => 119,  292 => 118,  288 => 116,  279 => 114,  275 => 113,  248 => 88,  238 => 87,  223 => 80,  213 => 79,  202 => 75,  195 => 70,  185 => 63,  173 => 54,  163 => 47,  150 => 37,  146 => 35,  142 => 32,  137 => 29,  134 => 28,  131 => 26,  121 => 25,  103 => 20,  92 => 22,  90 => 21,  87 => 20,  83 => 17,  78 => 14,  75 => 13,  72 => 11,  62 => 10,  39 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'invoices/invoice_edit_common.html.twig' #}

{% extends \"base/base_form_twocolumns_mid.html.twig\" %}

{# comment %}
    edycja danych faktury, część wspólna
{% endcomment #}


{% block base_form_main_left_div %}

    {# --------------------------------------------------------------------------------- #}
    Sprzedawca:<br>
    <h2><span class=\"badge badge-dark\">{{ seller.fname }}</span></h2>
    <br><br>
    {# --------------------------------------------------------------------------------- #}


    {# --------------------------------------------------------------------------------- #}
    {% block base_left_part_for_item_select %}{% endblock %}
    {# --------------------------------------------------------------------------------- #}

{% endblock %}

{% block base_form_main_right_div %}

    {# --------------------------------------------------------------------------------- #}
    Nabywca:<br>
    <h2><span class=\"badge badge-dark\">{{ customer.fname }}</span></h2>
    <br><br>
    {# --------------------------------------------------------------------------------- #}


    {# --------------------------------------------------------------------------------- #}
    <div class=\"form-group\">
        <label for=\"fNr\">numer faktury</label>
        <input type=\"text\" class=\"form-control fNr\" id=\"fNr\" name=\"fNr\" value=\"{{ fNr }}\"
               aria-describedby=\"fNrHelp\" placeholder=\"numer faktury\">
        <small id=\"sfNr\" class=\"form-text text-muted\">numer faktury -wymagany</small>
    </div>

    <table style=\"width:100%;\">
        <tr>
            <td style=\"width:50%;\">
    <div class=\"form-group\">
        <label>faktura z dnia</label>
        <input type=\"date\" name=\"dt_created\" max=\"3000-12-31\" value=\"{{ dt_created }}\"
            min=\"1000-01-01\" class=\"form-control\">
    </div>
            </td>
            <td>
    <div class=\"form-group\">
        <label>termin płatności</label>
        <input type=\"date\" name=\"dt_pait_to\" max=\"3000-12-31\" value=\"{{ dt_pait_to }}\"
            min=\"1000-01-01\" class=\"form-control\">
    </div>
            </td>
        </tr>
    </table>

    <div class=\"form-group\">
        <label>data dostarczenia usługi</label>
        <input type=\"date\" name=\"dt_delivery\" max=\"3000-12-31\" value=\"{{ dt_delivery }}\"
            min=\"1000-01-01\" class=\"form-control\">
    </div>


    <div class=\"form-group\">
        <label for=\"person_auth_name\">osoba upoważniona</label>
        <input type=\"text\" class=\"form-control person_auth_name\" id=\"person_auth_name\" name=\"person_auth_name\" value=\"{{ person_auth_name }}\"
               aria-describedby=\"nameHelp\" placeholder=\"\">
        <small id=\"sperson_auth_name\" class=\"form-text text-muted\">osoba upoważniona do wystawienia faktury</small>
    </div>
    {# --------------------------------------------------------------------------------- #}

{% endblock %}


{% block base_form_main_lower_buttons %}

    <button type=\"submit\" name=\"action\" value=\"OK\" class=\"btn btn-primary btn\">Zapisz</button>
    <button type=\"submit\" name=\"action\" value=\"delete\" class=\"btn btn-warning btn\">Usuń</button>
    <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>

{% endblock %}

{% block base_nav_footer_scripts %}

    <script>

        /** odszukaj element input, wyciągnij z nich funkcyjne klasy nez duplikacji
         *  dla każdej z nich sprawdź, czy jest na liście błędów,
         *  jeśli tak -dodaj klasę error, jeśli nie usuń klasę error
         */
        function do_with_error_class() {

            var input_list = document.getElementsByTagName('input');

            // pobieram wszystkie klasy:
            var form_input_class_list = [];
            for(var i=0;i<input_list.length;i++) {
                //input_list[i].classList.contains(\"active\");
                for(var j=0;j<input_list[i].classList.length;j++) {
                    var one_class = input_list[i].classList[j];
                    if((one_class != 'form-control') && (form_input_class_list.indexOf(one_class) < 0)) {
                        form_input_class_list.push(one_class);
                    }
                }
            }

            // to do wyświetlenia tylko
            var errors_message_list = [];
            {% for i in errors_message_list|default %}
                errors_message_list.push('{{ i }}');
            {% endfor %}

            var errors_message_redclass_list = [];
            {% for i in errors_message_redclass_list|default %}
                errors_message_redclass_list.push('{{ i }}');
            {% endfor %}

            // dla każdej z klas pobieram elementy i dodaję lub usuwam klasę error_input
            for(var k=0;k<form_input_class_list.length;k++) {
                // klasa, którą sprawdzam teraz:
                var one_class = form_input_class_list[k];
                // pobieram wszystkie elementy z tą klasą:
                var one_class_elements_list = document.getElementsByClassName(one_class);
                //console.log('elementy z klasą: \"' + one_class + '\" --> szt: ' + one_class_elements_list.length)
                // dla każdego z nich:
                for(var l=0;l<one_class_elements_list.length;l++) {
                    // jeśli ta klasa jest w błędnych -> zaznaczam error
                    if(  errors_message_redclass_list.indexOf(one_class) >= 0 ) {
                        //console.log('powinien być error')
                        if(!one_class_elements_list[l].classList.contains(\"error\")) {
                            //console.log('nie zawiera, więc dodaję error')
                            one_class_elements_list[l].classList.add(\"error\");
                        }
                    }else{
                        //console.log('NIE powinno być erroru')
                        if(one_class_elements_list[l].classList.contains(\"error\")) {
                            //console.log('zawiera, więc usuwam error')
                            one_class_elements_list[l].classList.remove(\"error\");
                        }
                    }
                }
            }
        }

        do_with_error_class();

    </script>

{% endblock %}
", "invoices/invoice_edit_common.html.twig", "/home/wiks/Dokumenty/projects/iai_task/php/iai_invoice/templates/invoices/invoice_edit_common.html.twig");
    }
}
