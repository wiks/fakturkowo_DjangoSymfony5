<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* invoices/invoices_list.html.twig */
class __TwigTemplate_a17618e3267799ac4ca963fc8665446a534793548f3551f2074f661f60050036 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'base_nav_main_div' => [$this, 'block_base_nav_main_div'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "base/base_nonav.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoices_list.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoices_list.html.twig"));

        $this->parent = $this->loadTemplate("base/base_nonav.html.twig", "invoices/invoices_list.html.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 9
    public function block_base_nav_main_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_main_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_main_div"));

        // line 10
        echo "
    <div class=\"alert alert-info\" role=\"alert\">
        Faktury
    </div>

    ";
        // line 15
        if ((isset($context["invoices_objs"]) || array_key_exists("invoices_objs", $context) ? $context["invoices_objs"] : (function () { throw new RuntimeError('Variable "invoices_objs" does not exist.', 15, $this->source); })())) {
            // line 16
            echo "        <table class=\"table\" style=\"width:100%;border-style: solid;border-width: 1px;\">
            <tr>
                <th style=\"width:25%\">nr</th>
                <th>nabywca</th>
                <th>kwota netto</th>
                <th>utworzona</th>
                <th>term.dostarczenia</th>
            </tr>
            ";
            // line 24
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["invoices_objs"]) || array_key_exists("invoices_objs", $context) ? $context["invoices_objs"] : (function () { throw new RuntimeError('Variable "invoices_objs" does not exist.', 24, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["invoice_obj"]) {
                // line 25
                echo "                <tr>
                    <td>
                        <h4>
                            <a href=\"";
                // line 28
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("invoice_show", ["invoice_id" => twig_get_attribute($this->env, $this->source, $context["invoice_obj"], "id", [], "any", false, false, false, 28)]), "html", null, true);
                echo "\">
                                ";
                // line 29
                if (twig_get_attribute($this->env, $this->source, $context["invoice_obj"], "nr", [], "any", false, false, false, 29)) {
                    // line 30
                    echo "                                    <span class=\"badge badge-dark\">";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_obj"], "nr", [], "any", false, false, false, 30), "html", null, true);
                    echo "</span>
                                ";
                } else {
                    // line 32
                    echo "                                    <span class=\"badge badge-danger\">faktura bez numeru</span>
                                ";
                }
                // line 34
                echo "                            </a>                            
                        </h4>
                    </td>
                    <td>
                        ";
                // line 38
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["invoice_obj"], "customer", [], "any", false, false, false, 38), "fname", [], "any", false, false, false, 38), "html", null, true);
                echo "
                    </td>
                    <td>
                        ";
                // line 41
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_obj"], "priceSumNetto", [], "any", false, false, false, 41), "html", null, true);
                echo " PLN
                    </td>
                    <td>
                        ";
                // line 44
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_obj"], "dtCreated", [], "any", false, false, false, 44), "Y-m-d"), "html", null, true);
                echo "
                    </td>
                    <td>
                        ";
                // line 47
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_obj"], "dtDelivery", [], "any", false, false, false, 47), "Y-m-d"), "html", null, true);
                echo "
                    </td>

                </tr>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['invoice_obj'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 52
            echo "       </table>

        ";
            // line 55
            echo "        ";
            echo $this->extensions['Knp\Bundle\PaginatorBundle\Twig\Extension\PaginationExtension']->render($this->env, (isset($context["invoices_objs"]) || array_key_exists("invoices_objs", $context) ? $context["invoices_objs"] : (function () { throw new RuntimeError('Variable "invoices_objs" does not exist.', 55, $this->source); })()));
            echo " 

    ";
        } else {
            // line 58
            echo "        <div class=\"alert alert-info\" role=\"alert\">
            lista jest pusta, dodaj pierwszą fakturę
        </div>
    ";
        }
        // line 62
        echo "    <a class=\"btn btn-primary\" href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("invoice_add");
        echo "\" role=\"button\">dodaj fakturę</a>
    <br><br>

    <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "invoices/invoices_list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  164 => 62,  158 => 58,  151 => 55,  147 => 52,  136 => 47,  130 => 44,  124 => 41,  118 => 38,  112 => 34,  108 => 32,  102 => 30,  100 => 29,  96 => 28,  91 => 25,  87 => 24,  77 => 16,  75 => 15,  68 => 10,  58 => 9,  35 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'invoices/invoices_list.html.twig' #}

{% extends \"base/base_nonav.html.twig\" %}

{# comment %}
    lista faktur
{% endcomment #}

{% block base_nav_main_div %}

    <div class=\"alert alert-info\" role=\"alert\">
        Faktury
    </div>

    {% if invoices_objs %}
        <table class=\"table\" style=\"width:100%;border-style: solid;border-width: 1px;\">
            <tr>
                <th style=\"width:25%\">nr</th>
                <th>nabywca</th>
                <th>kwota netto</th>
                <th>utworzona</th>
                <th>term.dostarczenia</th>
            </tr>
            {% for invoice_obj in invoices_objs %}
                <tr>
                    <td>
                        <h4>
                            <a href=\"{{ path('invoice_show', {'invoice_id': invoice_obj.id}) }}{# path('invoice_show', {invoice_id: invoice_obj.id}) #}\">
                                {% if invoice_obj.nr %}
                                    <span class=\"badge badge-dark\">{{ invoice_obj.nr }}</span>
                                {% else %}
                                    <span class=\"badge badge-danger\">faktura bez numeru</span>
                                {% endif %}
                            </a>                            
                        </h4>
                    </td>
                    <td>
                        {{ invoice_obj.customer.fname }}
                    </td>
                    <td>
                        {{ invoice_obj.priceSumNetto }} PLN
                    </td>
                    <td>
                        {{ invoice_obj.dtCreated|date('Y-m-d') }}
                    </td>
                    <td>
                        {{ invoice_obj.dtDelivery|date('Y-m-d') }}
                    </td>

                </tr>
            {% endfor %}
       </table>

        {#<!-- sprawdzam czy jest paginator -->#}
        {{ knp_pagination_render(invoices_objs) }} 

    {% else %}
        <div class=\"alert alert-info\" role=\"alert\">
            lista jest pusta, dodaj pierwszą fakturę
        </div>
    {% endif %}
    <a class=\"btn btn-primary\" href=\"{{ path('invoice_add') }}\" role=\"button\">dodaj fakturę</a>
    <br><br>

    <button type=\"submit\" name=\"action\" value=\"Cancel\" class=\"btn btn-secondary btn\">Wyjdź</button>

{% endblock %}
", "invoices/invoices_list.html.twig", "/home/wiks/Dokumenty/projects/iai_task/php/iai_invoice/templates/invoices/invoices_list.html.twig");
    }
}
