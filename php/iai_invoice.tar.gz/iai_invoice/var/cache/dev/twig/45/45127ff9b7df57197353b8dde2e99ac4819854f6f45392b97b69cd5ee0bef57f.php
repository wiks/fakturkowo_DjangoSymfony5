<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* invoices/invoice_edit.html.twig */
class __TwigTemplate_cdddc824a6606e12c888e4615933c7dfbc83ea929831be01b5a91873144463d1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'base_left_part_for_item_select' => [$this, 'block_base_left_part_for_item_select'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "invoices/invoice_edit_common.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_edit.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_edit.html.twig"));

        $this->parent = $this->loadTemplate("invoices/invoice_edit_common.html.twig", "invoices/invoice_edit.html.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 10
    public function block_base_left_part_for_item_select($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_left_part_for_item_select"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_left_part_for_item_select"));

        // line 11
        echo "
    ";
        // line 12
        if ((isset($context["invoices_items_richer"]) || array_key_exists("invoices_items_richer", $context) ? $context["invoices_items_richer"] : (function () { throw new RuntimeError('Variable "invoices_items_richer" does not exist.', 12, $this->source); })())) {
            // line 13
            echo "
        <table class=\"table\">

            ";
            // line 16
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["invoices_items_richer"]) || array_key_exists("invoices_items_richer", $context) ? $context["invoices_items_richer"] : (function () { throw new RuntimeError('Variable "invoices_items_richer" does not exist.', 16, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["invoice_item"]) {
                // line 17
                echo "                <tr>
                    <td>";
                // line 18
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 18), "html", null, true);
                echo "</td>
                    <td style=\"width:30%\" colspan=\"3\"><h4><span class=\"badge badge-dark\">";
                // line 19
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_item"], "name", [], "any", false, false, false, 19), "html", null, true);
                echo "</span></h4></td>
                    <td>
                        <a href=\"";
                // line 21
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("invoice_del_item", ["invoice_id" => twig_get_attribute($this->env, $this->source, (isset($context["invoice"]) || array_key_exists("invoice", $context) ? $context["invoice"] : (function () { throw new RuntimeError('Variable "invoice" does not exist.', 21, $this->source); })()), "id", [], "any", false, false, false, 21), "item_id" => twig_get_attribute($this->env, $this->source, $context["invoice_item"], "id", [], "any", false, false, false, 21), "iid" => twig_get_attribute($this->env, $this->source, $context["invoice_item"], "iid", [], "any", false, false, false, 21)]), "html", null, true);
                echo "\">
                            <ion-icon ios=\"ios-trash\" md=\"md-trash\" style=\"font-size: 32px;\"></ion-icon>
                        </a>
                    </td>
                    <td style=\"text-align:right;\">";
                // line 25
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_item"], "items_number", [], "any", false, false, false, 25), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_item"], "jm", [], "any", false, false, false, 25), "html", null, true);
                echo "</td>
                </tr>

                <tr>
                    <td></td>
                    <td>";
                // line 30
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_item"], "price_netto", [], "any", false, false, false, 30), "html", null, true);
                echo "</td>
                    <td>";
                // line 31
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_item"], "price_brutto", [], "any", false, false, false, 31), "html", null, true);
                echo "</td>
                    <td>";
                // line 32
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_item"], "value_netto", [], "any", false, false, false, 32), "html", null, true);
                echo "</td>
                    <td>";
                // line 33
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_item"], "vat", [], "any", false, false, false, 33), "html", null, true);
                echo "</td>
                    <td>";
                // line 34
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["invoice_item"], "value_brutto", [], "any", false, false, false, 34), "html", null, true);
                echo "</td>
                </tr>
                
            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['invoice_item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 38
            echo "
        </table>


        <br>

    ";
        } else {
            // line 45
            echo "        <div class=\"alert alert-info\" role=\"alert\">
            faktura nie zawiera żadnych pozycji
        </div>
    ";
        }
        // line 49
        echo "    
    <button type=\"submit\" name=\"action\" value=\"add_item\" class=\"btn btn-success btn\">Dodaj pozycję do faktury</button>
    <br><br><br>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "invoices/invoice_edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  173 => 49,  167 => 45,  158 => 38,  140 => 34,  136 => 33,  132 => 32,  128 => 31,  124 => 30,  114 => 25,  107 => 21,  102 => 19,  98 => 18,  95 => 17,  78 => 16,  73 => 13,  71 => 12,  68 => 11,  58 => 10,  35 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'invoices/invoice_edit.html.twig' #}

{% extends 'invoices/invoice_edit_common.html.twig' %}

{# comment %}
    edycja faktury, wybieranie przedmiotu do dodania
{% endcomment #}


{% block base_left_part_for_item_select %}

    {% if invoices_items_richer %}

        <table class=\"table\">

            {% for invoice_item in invoices_items_richer %}
                <tr>
                    <td>{{ loop.index }}</td>
                    <td style=\"width:30%\" colspan=\"3\"><h4><span class=\"badge badge-dark\">{{ invoice_item.name }}</span></h4></td>
                    <td>
                        <a href=\"{{ path('invoice_del_item', {invoice_id:invoice.id, item_id:invoice_item.id, iid:invoice_item.iid}) }}\">
                            <ion-icon ios=\"ios-trash\" md=\"md-trash\" style=\"font-size: 32px;\"></ion-icon>
                        </a>
                    </td>
                    <td style=\"text-align:right;\">{{ invoice_item.items_number }} {{ invoice_item.jm }}</td>
                </tr>

                <tr>
                    <td></td>
                    <td>{{ invoice_item.price_netto }}</td>
                    <td>{{ invoice_item.price_brutto }}</td>
                    <td>{{ invoice_item.value_netto }}</td>
                    <td>{{ invoice_item.vat }}</td>
                    <td>{{ invoice_item.value_brutto }}</td>
                </tr>
                
            {% endfor %}

        </table>


        <br>

    {% else %}
        <div class=\"alert alert-info\" role=\"alert\">
            faktura nie zawiera żadnych pozycji
        </div>
    {% endif %}
    
    <button type=\"submit\" name=\"action\" value=\"add_item\" class=\"btn btn-success btn\">Dodaj pozycję do faktury</button>
    <br><br><br>


{% endblock %}

", "invoices/invoice_edit.html.twig", "/home/wiks/Dokumenty/projects/iai_task/php/iai_invoice/templates/invoices/invoice_edit.html.twig");
    }
}
