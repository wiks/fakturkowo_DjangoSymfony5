<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* invoices/invoice_show_vat_sum_table.html.twig */
class __TwigTemplate_ba0ec324d569995c9a131993cdb3ab9af6aade4da0270d2411a1cd9ea9f5859b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_show_vat_sum_table.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_show_vat_sum_table.html.twig"));

        // line 2
        echo "

";
        // line 7
        echo "

Sprzedaż według cen brutto

<table class=\"table_w100\" style=\"border-style:solid;border-width:2px;\">
    <tr>
        <td style=\"width:25%;\" class=\"td_border_center\">PLN</td>
        <td style=\"width:25%;\" class=\"td_border_center\">Wartość netto</td>
        <td style=\"width:25%;\" class=\"td_border_center\">Wartość VAT</td>
        <td style=\"width:25%;\" class=\"td_border_center\">Wartość brutto</td>
    </tr>
    ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["vat_sum"]) || array_key_exists("vat_sum", $context) ? $context["vat_sum"] : (function () { throw new RuntimeError('Variable "vat_sum" does not exist.', 18, $this->source); })()), "list", [], "any", false, false, false, 18));
        foreach ($context['_seq'] as $context["_key"] => $context["vat_row"]) {
            // line 19
            echo "        <tr>
            ";
            // line 20
            if (twig_get_attribute($this->env, $this->source, $context["vat_row"], "wn", [], "any", false, false, false, 20)) {
                // line 21
                echo "                <td class=\"td_border_center\">stawka ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["vat_row"], "sv", [], "any", false, false, false, 21), "html", null, true);
                echo "%</td>
                <td class=\"td_border td_right\">";
                // line 22
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["vat_row"], "wn", [], "any", false, false, false, 22), 2, ".", ","), "html", null, true);
                echo "</td>
                <td class=\"td_border td_right\">";
                // line 23
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["vat_row"], "wv", [], "any", false, false, false, 23), 2, ".", ","), "html", null, true);
                echo "</td>
                <td class=\"td_border td_right\">";
                // line 24
                echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["vat_row"], "wb", [], "any", false, false, false, 24), 2, ".", ","), "html", null, true);
                echo "</td>
            ";
            }
            // line 26
            echo "        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['vat_row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        echo "    <tr>
        <td class=\"td_border_center\">Razem</td>
        <td class=\"td_border td_right\">";
        // line 30
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["vat_sum"]) || array_key_exists("vat_sum", $context) ? $context["vat_sum"] : (function () { throw new RuntimeError('Variable "vat_sum" does not exist.', 30, $this->source); })()), "sum", [], "any", false, false, false, 30), "wn", [], "any", false, false, false, 30), 2, ".", ","), "html", null, true);
        echo "</td>
        <td class=\"td_border td_right\">";
        // line 31
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["vat_sum"]) || array_key_exists("vat_sum", $context) ? $context["vat_sum"] : (function () { throw new RuntimeError('Variable "vat_sum" does not exist.', 31, $this->source); })()), "sum", [], "any", false, false, false, 31), "wv", [], "any", false, false, false, 31), 2, ".", ","), "html", null, true);
        echo "</td>
        <td class=\"td_border td_right\">";
        // line 32
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["vat_sum"]) || array_key_exists("vat_sum", $context) ? $context["vat_sum"] : (function () { throw new RuntimeError('Variable "vat_sum" does not exist.', 32, $this->source); })()), "sum", [], "any", false, false, false, 32), "wb", [], "any", false, false, false, 32), 2, ".", ","), "html", null, true);
        echo "</td>
    </tr>
</table>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "invoices/invoice_show_vat_sum_table.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 32,  102 => 31,  98 => 30,  94 => 28,  87 => 26,  82 => 24,  78 => 23,  74 => 22,  69 => 21,  67 => 20,  64 => 19,  60 => 18,  47 => 7,  43 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'invoices/invoice_show_vat_sum_table.html.twig' #}


{# comment %}
    tabela na fakturze sumaryczna dla VAT
{% endcomment #}


Sprzedaż według cen brutto

<table class=\"table_w100\" style=\"border-style:solid;border-width:2px;\">
    <tr>
        <td style=\"width:25%;\" class=\"td_border_center\">PLN</td>
        <td style=\"width:25%;\" class=\"td_border_center\">Wartość netto</td>
        <td style=\"width:25%;\" class=\"td_border_center\">Wartość VAT</td>
        <td style=\"width:25%;\" class=\"td_border_center\">Wartość brutto</td>
    </tr>
    {% for vat_row in vat_sum.list %}
        <tr>
            {% if vat_row.wn %}
                <td class=\"td_border_center\">stawka {{ vat_row.sv }}%</td>
                <td class=\"td_border td_right\">{{ (vat_row.wn)|number_format(2, '.', ',') }}</td>
                <td class=\"td_border td_right\">{{ (vat_row.wv)|number_format(2, '.', ',') }}</td>
                <td class=\"td_border td_right\">{{ (vat_row.wb)|number_format(2, '.', ',') }}</td>
            {% endif %}
        </tr>
    {% endfor %}
    <tr>
        <td class=\"td_border_center\">Razem</td>
        <td class=\"td_border td_right\">{{ (vat_sum.sum.wn)|number_format(2, '.', ',') }}</td>
        <td class=\"td_border td_right\">{{ (vat_sum.sum.wv)|number_format(2, '.', ',') }}</td>
        <td class=\"td_border td_right\">{{ (vat_sum.sum.wb)|number_format(2, '.', ',') }}</td>
    </tr>
</table>
", "invoices/invoice_show_vat_sum_table.html.twig", "/home/wiks/Dokumenty/projects/iai_task/php/iai_invoice/templates/invoices/invoice_show_vat_sum_table.html.twig");
    }
}
