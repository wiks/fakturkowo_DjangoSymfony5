<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* invoices/invoice_add.html.twig */
class __TwigTemplate_30eee6ef1e56dd046744001f7f49818c8d4b9a0fb32b1cf16782b8e4f6053f7a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'base_nav_main_div' => [$this, 'block_base_nav_main_div'],
            'base_basic_footer_scripts' => [$this, 'block_base_basic_footer_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "base/base_nonav.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_add.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_add.html.twig"));

        $this->parent = $this->loadTemplate("base/base_nonav.html.twig", "invoices/invoice_add.html.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 9
    public function block_base_nav_main_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_main_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_main_div"));

        // line 10
        echo "
    <div class=\"alert alert-info\" role=\"alert\">
        Tworzenie nowej faktury, wyszukaj nabywcę.<br>
        Podaj przynajmniej 3 znaki, zawierające się w numerze NIP, REGON lub PESEL.
        Wyświetlonych zostanie kilka znalezionych firm.
        Jeśli na liście jest poszukiwana, kliknij ją, jeśli nie wpisuj dalej numer identyfikujący.
    </div>

    <div ng-app=\"myApp\" ng-controller=\"custCtrl\">
        <div class=\"container\">

            <div class=\"row\">
                <div class=\"col\">

                    <div class=\"input-group input-group\">
                        <div class=\"input-group-prepend\">
                            <span class=\"input-group-text\" id=\"inputGroup-sizing-lg\">nazwa, NIP, REGON lub PESEL:</span>
                        </div>
                        <input type=\"text\"
                               id=\"lookfor\"
                               class=\"form-control\"
                               aria-describedby=\"inputGroup-sizing-sm\"
                               ng-model=\"lookfor\"
                               ng-change=\"myFunc()\"
                        >
                    </div>
                </div>
            </div>

            ";
        // line 41
        echo "
                <div ng-if=\"item_list.length>0 && item_list.length< 10\">
            ";
        echo "
                    <ul class=\"list-group\">
                        <li class=\"list-group-item\" ng-repeat=\"item in item_list\">

                            <a href=\"";
        // line 45
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("invoice_add");
        echo "/";
        // line 47
        echo "{{ item['id'] }}/\">
                                <h3><span class=\"badge badge-info\">{{ item['fname'] }}</span></h3>
                            </a>";
        echo "
                        </li>
                    </ul>

                </div>

        </div> <!-- container -->
    </div> <!-- AngularJS -->

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 58
    public function block_base_basic_footer_scripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_basic_footer_scripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_basic_footer_scripts"));

        // line 59
        echo "
    <script type=\"text/javascript\">
        var angular_url = '";
        // line 61
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\HttpFoundationExtension']->generateAbsoluteUrl($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("angular_url")), "html", null, true);
        echo "';
    </script>

    <script src=\"";
        // line 64
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\HttpFoundationExtension']->generateAbsoluteUrl($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/mangular_customer.js")), "html", null, true);
        echo "\" type=\"text/javascript\"></script>
    
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "invoices/invoice_add.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  154 => 64,  148 => 61,  144 => 59,  134 => 58,  112 => 47,  109 => 45,  100 => 41,  69 => 10,  59 => 9,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'invoices/invoice_add.html.twig' #}

{% extends \"base/base_nonav.html.twig\" %}

{# comment %}
    nowa faktura, wyszukiwanie klienta
{% endcomment #}

{% block base_nav_main_div %}

    <div class=\"alert alert-info\" role=\"alert\">
        Tworzenie nowej faktury, wyszukaj nabywcę.<br>
        Podaj przynajmniej 3 znaki, zawierające się w numerze NIP, REGON lub PESEL.
        Wyświetlonych zostanie kilka znalezionych firm.
        Jeśli na liście jest poszukiwana, kliknij ją, jeśli nie wpisuj dalej numer identyfikujący.
    </div>

    <div ng-app=\"myApp\" ng-controller=\"custCtrl\">
        <div class=\"container\">

            <div class=\"row\">
                <div class=\"col\">

                    <div class=\"input-group input-group\">
                        <div class=\"input-group-prepend\">
                            <span class=\"input-group-text\" id=\"inputGroup-sizing-lg\">nazwa, NIP, REGON lub PESEL:</span>
                        </div>
                        <input type=\"text\"
                               id=\"lookfor\"
                               class=\"form-control\"
                               aria-describedby=\"inputGroup-sizing-sm\"
                               ng-model=\"lookfor\"
                               ng-change=\"myFunc()\"
                        >
                    </div>
                </div>
            </div>

            {% verbatim %}
                <div ng-if=\"item_list.length>0 && item_list.length< 10\">
            {% endverbatim %}
                    <ul class=\"list-group\">
                        <li class=\"list-group-item\" ng-repeat=\"item in item_list\">

                            <a href=\"{{ path('invoice_add') }}/{% verbatim %}{{ item['id'] }}/\">
                                <h3><span class=\"badge badge-info\">{{ item['fname'] }}</span></h3>
                            </a>{% endverbatim %}
                        </li>
                    </ul>

                </div>

        </div> <!-- container -->
    </div> <!-- AngularJS -->

{% endblock %}

{% block base_basic_footer_scripts %}

    <script type=\"text/javascript\">
        var angular_url = '{{ absolute_url(path('angular_url')) }}';
    </script>

    <script src=\"{{ absolute_url(asset('js/mangular_customer.js')) }}\" type=\"text/javascript\"></script>
    
{% endblock %}
", "invoices/invoice_add.html.twig", "/home/wiks/Dokumenty/projects/iai_task/php/iai_invoice/templates/invoices/invoice_add.html.twig");
    }
}
