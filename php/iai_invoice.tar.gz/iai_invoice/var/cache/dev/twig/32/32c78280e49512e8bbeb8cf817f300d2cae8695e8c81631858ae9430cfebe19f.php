<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* customers/firm_show_mini.html.twig */
class __TwigTemplate_70310c1ef090bf9979b1ff78e41cff045ec2f52727befe5c0c7fb17afb66b03b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "customers/firm_show_mini.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "customers/firm_show_mini.html.twig"));

        // line 2
        echo "
<table>
    <tr>
        <th>
            ";
        // line 6
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["shortfirm"]) || array_key_exists("shortfirm", $context) ? $context["shortfirm"] : (function () { throw new RuntimeError('Variable "shortfirm" does not exist.', 6, $this->source); })()), "firmName", [], "any", false, false, false, 6), "html", null, true);
        echo "
        </th>
    </tr>

    ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["shortfirm"]) || array_key_exists("shortfirm", $context) ? $context["shortfirm"] : (function () { throw new RuntimeError('Variable "shortfirm" does not exist.', 10, $this->source); })()), "address_list", [], "any", false, false, false, 10));
        foreach ($context['_seq'] as $context["_key"] => $context["address_line"]) {
            // line 11
            echo "        <tr>
            <td>
                ";
            // line 13
            echo twig_escape_filter($this->env, $context["address_line"], "html", null, true);
            echo "
            </td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['address_line'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "
    <tr>
        <td>
            NIP: ";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["shortfirm"]) || array_key_exists("shortfirm", $context) ? $context["shortfirm"] : (function () { throw new RuntimeError('Variable "shortfirm" does not exist.', 20, $this->source); })()), "firmNip", [], "any", false, false, false, 20), "html", null, true);
        echo "
        </td>
        <td>
            REGON: ";
        // line 23
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["shortfirm"]) || array_key_exists("shortfirm", $context) ? $context["shortfirm"] : (function () { throw new RuntimeError('Variable "shortfirm" does not exist.', 23, $this->source); })()), "firmRegon", [], "any", false, false, false, 23), "html", null, true);
        echo "
        </td>
    </tr>

    ";
        // line 27
        if ((((isset($context["firmPesel"]) || array_key_exists("firmPesel", $context))) ? (_twig_default_filter((isset($context["firmPesel"]) || array_key_exists("firmPesel", $context) ? $context["firmPesel"] : (function () { throw new RuntimeError('Variable "firmPesel" does not exist.', 27, $this->source); })()))) : (""))) {
            // line 28
            echo "        <tr>
            <td>
                PESEL: ";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["shortfirm"]) || array_key_exists("shortfirm", $context) ? $context["shortfirm"] : (function () { throw new RuntimeError('Variable "shortfirm" does not exist.', 30, $this->source); })()), "firmPesel", [], "any", false, false, false, 30), "html", null, true);
            echo "
            </td>
        </tr>
    ";
        }
        // line 34
        echo "
    <tr>
        <td>
            Bank: ";
        // line 37
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["shortfirm"]) || array_key_exists("shortfirm", $context) ? $context["shortfirm"] : (function () { throw new RuntimeError('Variable "shortfirm" does not exist.', 37, $this->source); })()), "firm_account_list", [], "any", false, false, false, 37), 1, [], "any", false, false, false, 37), "html", null, true);
        echo "<br>
            ";
        // line 38
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["shortfirm"]) || array_key_exists("shortfirm", $context) ? $context["shortfirm"] : (function () { throw new RuntimeError('Variable "shortfirm" does not exist.', 38, $this->source); })()), "firm_account_list", [], "any", false, false, false, 38), 0, [], "any", false, false, false, 38), "html", null, true);
        echo "
        </td>
    </tr>

    ";
        // line 42
        if (((twig_get_attribute($this->env, $this->source, ($context["shortfirm"] ?? null), "mInputEmail", [], "any", true, true, false, 42)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, ($context["shortfirm"] ?? null), "mInputEmail", [], "any", false, false, false, 42))) : (""))) {
            // line 43
            echo "        <tr>
            <td>
                Adres email: ";
            // line 45
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["shortfirm"]) || array_key_exists("shortfirm", $context) ? $context["shortfirm"] : (function () { throw new RuntimeError('Variable "shortfirm" does not exist.', 45, $this->source); })()), "mInputEmail", [], "any", false, false, false, 45), "html", null, true);
            echo "
            </td>
        </tr>
    ";
        }
        // line 49
        echo "
</table>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "customers/firm_show_mini.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  134 => 49,  127 => 45,  123 => 43,  121 => 42,  114 => 38,  110 => 37,  105 => 34,  98 => 30,  94 => 28,  92 => 27,  85 => 23,  79 => 20,  74 => 17,  64 => 13,  60 => 11,  56 => 10,  49 => 6,  43 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'customers/firm_show_mini.html.twig' #}

<table>
    <tr>
        <th>
            {{ shortfirm.firmName }}
        </th>
    </tr>

    {% for address_line in shortfirm.address_list %}
        <tr>
            <td>
                {{ address_line }}
            </td>
        </tr>
    {% endfor %}

    <tr>
        <td>
            NIP: {{ shortfirm.firmNip }}
        </td>
        <td>
            REGON: {{ shortfirm.firmRegon }}
        </td>
    </tr>

    {% if firmPesel|default %}
        <tr>
            <td>
                PESEL: {{ shortfirm.firmPesel }}
            </td>
        </tr>
    {% endif %}

    <tr>
        <td>
            Bank: {{ shortfirm.firm_account_list.1 }}<br>
            {{ shortfirm.firm_account_list.0 }}
        </td>
    </tr>

    {% if shortfirm.mInputEmail|default %}
        <tr>
            <td>
                Adres email: {{ shortfirm.mInputEmail }}
            </td>
        </tr>
    {% endif %}

</table>
", "customers/firm_show_mini.html.twig", "/home/wiks/Dokumenty/projects/iai_task/php/iai_invoice/templates/customers/firm_show_mini.html.twig");
    }
}
