<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* invoices/invoice_show_common.html.twig */
class __TwigTemplate_a58e8a8a99282166e783dc497b8e14ac9c2d3d145f1fcf18db641e291d80fe7b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'base_basic_style' => [$this, 'block_base_basic_style'],
            'base_form_main_upper_div' => [$this, 'block_base_form_main_upper_div'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "base/base_form_twocolumns_mid.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_show_common.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_show_common.html.twig"));

        $this->parent = $this->loadTemplate("base/base_form_twocolumns_mid.html.twig", "invoices/invoice_show_common.html.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 9
    public function block_base_basic_style($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_basic_style"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_basic_style"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 12
    public function block_base_form_main_upper_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_upper_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_upper_div"));

        // line 13
        echo "
    <table style=\"width: 100%;\">
        <tr>
            <td style=\"width: 60%;\">

                Sprzedawca:
                ";
        // line 19
        $__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 = $context;
        $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 = ["shortfirm" => (isset($context["shortfirm_seller"]) || array_key_exists("shortfirm_seller", $context) ? $context["shortfirm_seller"] : (function () { throw new RuntimeError('Variable "shortfirm_seller" does not exist.', 19, $this->source); })())];
        if (!twig_test_iterable($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144)) {
            throw new RuntimeError('Variables passed to the "with" tag must be a hash.', 19, $this->getSourceContext());
        }
        $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 = twig_to_array($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144);
        $context = $this->env->mergeGlobals(array_merge($context, $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144));
        // line 20
        echo "                    ";
        $this->loadTemplate("customers/firm_show_mini.html.twig", "invoices/invoice_show_common.html.twig", 20)->display($context);
        // line 21
        echo "                ";
        $context = $__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4;
        // line 22
        echo "
            </td>
            <td style=\"text-align: right;\">

                <h2>Faktura nr: ";
        // line 26
        echo twig_escape_filter($this->env, (isset($context["fNr"]) || array_key_exists("fNr", $context) ? $context["fNr"] : (function () { throw new RuntimeError('Variable "fNr" does not exist.', 26, $this->source); })()), "html", null, true);
        echo "</h2>

                z dnia: ";
        // line 28
        echo twig_escape_filter($this->env, (isset($context["dt_created"]) || array_key_exists("dt_created", $context) ? $context["dt_created"] : (function () { throw new RuntimeError('Variable "dt_created" does not exist.', 28, $this->source); })()), "html", null, true);
        echo "<br>

                ";
        // line 30
        if ((((isset($context["dt_delivery"]) || array_key_exists("dt_delivery", $context))) ? (_twig_default_filter((isset($context["dt_delivery"]) || array_key_exists("dt_delivery", $context) ? $context["dt_delivery"] : (function () { throw new RuntimeError('Variable "dt_delivery" does not exist.', 30, $this->source); })()))) : (""))) {
            // line 31
            echo "                    data dostarczenia usługi: ";
            echo twig_escape_filter($this->env, (isset($context["dt_delivery"]) || array_key_exists("dt_delivery", $context) ? $context["dt_delivery"] : (function () { throw new RuntimeError('Variable "dt_delivery" does not exist.', 31, $this->source); })()), "html", null, true);
            echo "<br>
                ";
        }
        // line 33
        echo "
            </td>
        </tr>
    </table>


    <br><br><br>
    Nabywca:
    ";
        // line 41
        $__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b = $context;
        $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 = ["shortfirm" => (isset($context["shortfirm_customer"]) || array_key_exists("shortfirm_customer", $context) ? $context["shortfirm_customer"] : (function () { throw new RuntimeError('Variable "shortfirm_customer" does not exist.', 41, $this->source); })())];
        if (!twig_test_iterable($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002)) {
            throw new RuntimeError('Variables passed to the "with" tag must be a hash.', 41, $this->getSourceContext());
        }
        $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 = twig_to_array($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002);
        $context = $this->env->mergeGlobals(array_merge($context, $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002));
        // line 42
        echo "        ";
        $this->loadTemplate("customers/firm_show_mini.html.twig", "invoices/invoice_show_common.html.twig", 42)->display($context);
        // line 43
        echo "    ";
        $context = $__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b;
        echo "    
    <br><br><br>


    <table class=\"table_w100\">
        <tr>
            <td class=\"td_right\">
                Forma płatności: ";
        // line 50
        echo twig_escape_filter($this->env, (isset($context["paid_form"]) || array_key_exists("paid_form", $context) ? $context["paid_form"] : (function () { throw new RuntimeError('Variable "paid_form" does not exist.', 50, $this->source); })()), "html", null, true);
        echo "
            </td>
        </tr>
        <tr>
            <td class=\"td_right\">
                Termin płatności: ";
        // line 55
        echo twig_escape_filter($this->env, (isset($context["dt_pait_to"]) || array_key_exists("dt_pait_to", $context) ? $context["dt_pait_to"] : (function () { throw new RuntimeError('Variable "dt_pait_to" does not exist.', 55, $this->source); })()), "html", null, true);
        echo "
            </td>
        </tr>
        <tr>
            <td>
                <table class=\"table_w100\" style=\"border-style:solid;border-width:2px;\">
                    <tr class=\"tr_border_center\">
                        <td style=\"width:5%;\">L.p.</td>
                        <td style=\"width:45%;\">Nazwa towaru / usługi</td>
                        <td style=\"width:5%;\">PKWiU</td>
                        <td style=\"width:5%;\">Ilość</td>
                        <td style=\"width:5%;\">J.m.</td>
                        <td style=\"width:10%;\">
                            <table class=\"table_w100\">
                                <tr>
                                    <td class=\"td_border_center\">cena jedn. brutto
                                    </td>
                                </tr>
                                <tr>
                                    <td class=\"td_border_center\">cena jedn. netto</td>
                                </tr>
                            </table>
                        </td>
                        <td style=\"width:5%;\">Wartość netto</td>
                        <td style=\"width:5%;\">VAT</td>
                        <td style=\"width:5%;\">Wartość brutto</td>
                    </tr>

                    ";
        // line 83
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["invoices_items_richer"]) || array_key_exists("invoices_items_richer", $context) ? $context["invoices_items_richer"] : (function () { throw new RuntimeError('Variable "invoices_items_richer" does not exist.', 83, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["invoice_item"]) {
            // line 84
            echo "                        ";
            $this->loadTemplate("invoices/invoice_show_common_one_row.html.twig", "invoices/invoice_show_common.html.twig", 84)->display($context);
            // line 85
            echo "                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['invoice_item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 86
        echo "
                </table>
            </td>
        </tr>
        <tr style=\"height:20px\">
            <td class=\"td_right\">

            </td>
        </tr>
        <tr>
            <td class=\"td_right\">
                <table class=\"table_w100\">
                    <tr>
                        <td style=\"width:50%;\"></td>
                        <td>
                            ";
        // line 101
        $this->loadTemplate("invoices/invoice_show_vat_sum_table.html.twig", "invoices/invoice_show_common.html.twig", 101)->display($context);
        // line 102
        echo "                        </td>
                    </tr>
                </table>

            </td>
        </tr>
        <tr>
            <td class=\"td_left\">
                razem: ";
        // line 110
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (isset($context["price_sum_brutto"]) || array_key_exists("price_sum_brutto", $context) ? $context["price_sum_brutto"] : (function () { throw new RuntimeError('Variable "price_sum_brutto" does not exist.', 110, $this->source); })()), 2, ".", ","), "html", null, true);
        echo " PLN
            </td>
        </tr>
        <tr>
            <td class=\"td_left\">
                słownie: ";
        // line 115
        echo twig_escape_filter($this->env, (isset($context["price_sum_brutto_translated"]) || array_key_exists("price_sum_brutto_translated", $context) ? $context["price_sum_brutto_translated"] : (function () { throw new RuntimeError('Variable "price_sum_brutto_translated" does not exist.', 115, $this->source); })()), "html", null, true);
        echo " PLN
            </td>
        </tr>
        <tr>
            <td class=\"td_left\">
                zapłacono: ";
        // line 120
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (isset($context["paid_sum_brutto"]) || array_key_exists("paid_sum_brutto", $context) ? $context["paid_sum_brutto"] : (function () { throw new RuntimeError('Variable "paid_sum_brutto" does not exist.', 120, $this->source); })()), 2, ".", ","), "html", null, true);
        echo " PLN
            </td>
        </tr>
        <tr>
            <td class=\"td_left\">
                pozostało do zapłaty: ";
        // line 125
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, (isset($context["price_sum_brutto"]) || array_key_exists("price_sum_brutto", $context) ? $context["price_sum_brutto"] : (function () { throw new RuntimeError('Variable "price_sum_brutto" does not exist.', 125, $this->source); })()), 2, ".", ","), "html", null, true);
        echo " PLN
            </td>
        </tr>
        <tr style=\"height:100px\">
            <td class=\"td_right\"></td>
        </tr>
        <tr>
            <td class=\"td_right\">
                <table class=\"table_w100\">
                    <tr>
                        <td style=\"width:50%;text-align: center;\">
                            ...<br>
                            podpis osoby upoważnionej do odbioru faktury:<br>
                            ...<br>
                        </td>
                        <td style=\"text-align: center;\">
                            ";
        // line 141
        echo twig_escape_filter($this->env, (isset($context["person_auth_name"]) || array_key_exists("person_auth_name", $context) ? $context["person_auth_name"] : (function () { throw new RuntimeError('Variable "person_auth_name" does not exist.', 141, $this->source); })()), "html", null, true);
        echo "<br>
                            podpis osoby upoważnionej do wystawienia faktury:<br>
                            ...<br>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr style=\"height:200px\">
            <td class=\"td_right\">

            </td>
        </tr>
    </table>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "invoices/invoice_show_common.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  310 => 141,  291 => 125,  283 => 120,  275 => 115,  267 => 110,  257 => 102,  255 => 101,  238 => 86,  224 => 85,  221 => 84,  204 => 83,  173 => 55,  165 => 50,  154 => 43,  151 => 42,  143 => 41,  133 => 33,  127 => 31,  125 => 30,  120 => 28,  115 => 26,  109 => 22,  106 => 21,  103 => 20,  95 => 19,  87 => 13,  77 => 12,  59 => 9,  36 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'invoices/invoice_show_common.html.twig' #}

{% extends \"base/base_form_twocolumns_mid.html.twig\" %}

{# comment %}
    podgląd danych faktury
{% endcomment %#}

{% block base_basic_style %}{% endblock %}


{% block base_form_main_upper_div %}

    <table style=\"width: 100%;\">
        <tr>
            <td style=\"width: 60%;\">

                Sprzedawca:
                {% with {shortfirm: shortfirm_seller} %}
                    {% include 'customers/firm_show_mini.html.twig' %}
                {% endwith %}

            </td>
            <td style=\"text-align: right;\">

                <h2>Faktura nr: {{ fNr }}</h2>

                z dnia: {{ dt_created }}<br>

                {% if dt_delivery|default %}
                    data dostarczenia usługi: {{ dt_delivery }}<br>
                {% endif %}

            </td>
        </tr>
    </table>


    <br><br><br>
    Nabywca:
    {% with {shortfirm: shortfirm_customer} %}
        {% include 'customers/firm_show_mini.html.twig' %}
    {% endwith %}    
    <br><br><br>


    <table class=\"table_w100\">
        <tr>
            <td class=\"td_right\">
                Forma płatności: {{ paid_form }}
            </td>
        </tr>
        <tr>
            <td class=\"td_right\">
                Termin płatności: {{ dt_pait_to }}
            </td>
        </tr>
        <tr>
            <td>
                <table class=\"table_w100\" style=\"border-style:solid;border-width:2px;\">
                    <tr class=\"tr_border_center\">
                        <td style=\"width:5%;\">L.p.</td>
                        <td style=\"width:45%;\">Nazwa towaru / usługi</td>
                        <td style=\"width:5%;\">PKWiU</td>
                        <td style=\"width:5%;\">Ilość</td>
                        <td style=\"width:5%;\">J.m.</td>
                        <td style=\"width:10%;\">
                            <table class=\"table_w100\">
                                <tr>
                                    <td class=\"td_border_center\">cena jedn. brutto
                                    </td>
                                </tr>
                                <tr>
                                    <td class=\"td_border_center\">cena jedn. netto</td>
                                </tr>
                            </table>
                        </td>
                        <td style=\"width:5%;\">Wartość netto</td>
                        <td style=\"width:5%;\">VAT</td>
                        <td style=\"width:5%;\">Wartość brutto</td>
                    </tr>

                    {% for invoice_item in invoices_items_richer %}
                        {% include 'invoices/invoice_show_common_one_row.html.twig' %}
                    {% endfor %}

                </table>
            </td>
        </tr>
        <tr style=\"height:20px\">
            <td class=\"td_right\">

            </td>
        </tr>
        <tr>
            <td class=\"td_right\">
                <table class=\"table_w100\">
                    <tr>
                        <td style=\"width:50%;\"></td>
                        <td>
                            {% include 'invoices/invoice_show_vat_sum_table.html.twig' %}
                        </td>
                    </tr>
                </table>

            </td>
        </tr>
        <tr>
            <td class=\"td_left\">
                razem: {{ (price_sum_brutto)|number_format(2, '.', ',') }} PLN
            </td>
        </tr>
        <tr>
            <td class=\"td_left\">
                słownie: {{ price_sum_brutto_translated }} PLN
            </td>
        </tr>
        <tr>
            <td class=\"td_left\">
                zapłacono: {{ (paid_sum_brutto)|number_format(2, '.', ',') }} PLN
            </td>
        </tr>
        <tr>
            <td class=\"td_left\">
                pozostało do zapłaty: {{ (price_sum_brutto)|number_format(2, '.', ',') }} PLN
            </td>
        </tr>
        <tr style=\"height:100px\">
            <td class=\"td_right\"></td>
        </tr>
        <tr>
            <td class=\"td_right\">
                <table class=\"table_w100\">
                    <tr>
                        <td style=\"width:50%;text-align: center;\">
                            ...<br>
                            podpis osoby upoważnionej do odbioru faktury:<br>
                            ...<br>
                        </td>
                        <td style=\"text-align: center;\">
                            {{ person_auth_name }}<br>
                            podpis osoby upoważnionej do wystawienia faktury:<br>
                            ...<br>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr style=\"height:200px\">
            <td class=\"td_right\">

            </td>
        </tr>
    </table>

{% endblock %}
", "invoices/invoice_show_common.html.twig", "/home/wiks/Dokumenty/projects/iai_task/php/iai_invoice/templates/invoices/invoice_show_common.html.twig");
    }
}
