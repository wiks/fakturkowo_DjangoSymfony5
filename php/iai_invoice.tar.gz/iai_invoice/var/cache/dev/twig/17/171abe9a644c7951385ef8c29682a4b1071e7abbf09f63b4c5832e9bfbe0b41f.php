<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* customers/firm_edit.html.twig */
class __TwigTemplate_3d359cd87b9e155493360e66f16038dbe6669bd05643c5454b3e5e25e71f2dfb extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'base_form_main_upper_div' => [$this, 'block_base_form_main_upper_div'],
            'base_form_main_head_div' => [$this, 'block_base_form_main_head_div'],
            'base_form_main_left_div' => [$this, 'block_base_form_main_left_div'],
            'base_form_main_right_div' => [$this, 'block_base_form_main_right_div'],
            'base_nav_footer_scripts' => [$this, 'block_base_nav_footer_scripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 3
        return "base/base_form_twocolumns_twobuttons.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "customers/firm_edit.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "customers/firm_edit.html.twig"));

        $this->parent = $this->loadTemplate("base/base_form_twocolumns_twobuttons.html.twig", "customers/firm_edit.html.twig", 3);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 10
    public function block_base_form_main_upper_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_upper_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_upper_div"));

        // line 11
        echo "
    ";
        // line 12
        $this->displayBlock('base_form_main_head_div', $context, $blocks);
        // line 13
        echo "
    <div class=\"form-group\">
        <div class=\"input-group-prepend\">
            <span class=\"input-group-text\">nazwa firmy</span>
            <input type=\"text\" class=\"form-control firmName\" id=\"firmName\" name=\"firmName\" value=\"";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["firmName"]) || array_key_exists("firmName", $context) ? $context["firmName"] : (function () { throw new RuntimeError('Variable "firmName" does not exist.', 17, $this->source); })()), "html", null, true);
        echo "\"
                   aria-describedby=\"firmNameHelp\" placeholder=\"nazwa\">
        </div>
        <small id=\"sfirmName\" class=\"form-text text-muted\">nazwa firmy -wymagana</small>
    </div>

    <!-- ew. dropzone do wrzucenia ikonki -->

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 12
    public function block_base_form_main_head_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_head_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_head_div"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 27
    public function block_base_form_main_left_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_left_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_left_div"));

        // line 28
        echo "
    <div class=\"form-group\">
        <label for=\"firmAdres1\">adres</label>
        <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres1\" name=\"firmAdres1\" value=\"";
        // line 31
        echo twig_escape_filter($this->env, (isset($context["firmAdres1"]) || array_key_exists("firmAdres1", $context) ? $context["firmAdres1"] : (function () { throw new RuntimeError('Variable "firmAdres1" does not exist.', 31, $this->source); })()), "html", null, true);
        echo "\"
               aria-describedby=\"firmAdres1Help\" placeholder=\"adres -wymagana choć jedna linia\">
        <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres2\" name=\"firmAdres2\" value=\"";
        // line 33
        echo twig_escape_filter($this->env, (isset($context["firmAdres2"]) || array_key_exists("firmAdres2", $context) ? $context["firmAdres2"] : (function () { throw new RuntimeError('Variable "firmAdres2" does not exist.', 33, $this->source); })()), "html", null, true);
        echo "\"
               aria-describedby=\"firmAdres1Help\">
        <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres3\" name=\"firmAdres3\" value=\"";
        // line 35
        echo twig_escape_filter($this->env, (isset($context["firmAdres3"]) || array_key_exists("firmAdres3", $context) ? $context["firmAdres3"] : (function () { throw new RuntimeError('Variable "firmAdres3" does not exist.', 35, $this->source); })()), "html", null, true);
        echo "\"
               aria-describedby=\"firmAdres1Help\">
        <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres4\" name=\"firmAdres4\" value=\"";
        // line 37
        echo twig_escape_filter($this->env, (isset($context["firmAdres4"]) || array_key_exists("firmAdres4", $context) ? $context["firmAdres4"] : (function () { throw new RuntimeError('Variable "firmAdres4" does not exist.', 37, $this->source); })()), "html", null, true);
        echo "\"
               aria-describedby=\"firmAdres1Help\">
        <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres5\" name=\"firmAdres5\" value=\"";
        // line 39
        echo twig_escape_filter($this->env, (isset($context["firmAdres5"]) || array_key_exists("firmAdres5", $context) ? $context["firmAdres5"] : (function () { throw new RuntimeError('Variable "firmAdres5" does not exist.', 39, $this->source); })()), "html", null, true);
        echo "\"
               aria-describedby=\"firmAdres1Help\">

        <small id=\"sfirmAdres1\" class=\"form-text text-muted\">adres firmy -wymagany, w zależności od potrzeb ile linii. Obowiązkowa tylko pierwsza</small>
    </div>

    <div class=\"form-group\">
        <div class=\"input-group-prepend\">
            <span class=\"input-group-text\">adres email</span>
            <input type=\"email\" class=\"form-control mInputEmail\" id=\"mInputEmail\" name=\"mInputEmail\" value=\"";
        // line 48
        echo twig_escape_filter($this->env, (isset($context["mInputEmail"]) || array_key_exists("mInputEmail", $context) ? $context["mInputEmail"] : (function () { throw new RuntimeError('Variable "mInputEmail" does not exist.', 48, $this->source); })()), "html", null, true);
        echo "\"
                   aria-describedby=\"emailHelp\" placeholder=\"email -opcjonalnie\">
        </div>
        <small id=\"semail\" class=\"form-text text-muted\">jeśli tylko chcesz</small>
    </div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 56
    public function block_base_form_main_right_div($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_right_div"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_form_main_right_div"));

        // line 57
        echo "
    <div class=\"form-group\">
        <div class=\"input-group-prepend\">
            <span class=\"input-group-text\">NIP</span>
            <input type=\"text\" class=\"form-control firmNip\" id=\"firmNip\" name=\"firmNip\" value=\"";
        // line 61
        echo twig_escape_filter($this->env, (isset($context["firmNip"]) || array_key_exists("firmNip", $context) ? $context["firmNip"] : (function () { throw new RuntimeError('Variable "firmNip" does not exist.', 61, $this->source); })()), "html", null, true);
        echo "\"
                   aria-describedby=\"firmNipHelp\" placeholder=\"NIP\">
        </div>
        <small id=\"sfirmNip\" class=\"form-text text-muted\">NIP firmy -opcjonalnie</small>
    </div>

    <div class=\"form-group\">
        <div class=\"input-group-prepend\">
            <span class=\"input-group-text\">REGON</span>
            <input type=\"text\" class=\"form-control firmRegon\" id=\"firmRegon\" name=\"firmRegon\" value=\"";
        // line 70
        echo twig_escape_filter($this->env, (isset($context["firmRegon"]) || array_key_exists("firmRegon", $context) ? $context["firmRegon"] : (function () { throw new RuntimeError('Variable "firmRegon" does not exist.', 70, $this->source); })()), "html", null, true);
        echo "\"
                   aria-describedby=\"firmNipHelp\" placeholder=\"REGON\">
        </div>
        <small id=\"sfirmRegon\" class=\"form-text text-muted\">REGON firmy -opcjonalnie</small>
    </div>

    <div class=\"form-group\">
        <div class=\"input-group-prepend\">
            <span class=\"input-group-text\">PESEL</span>
            <input type=\"text\" class=\"form-control firmPesel\" id=\"firmPesel\" name=\"firmPesel\" value=\"";
        // line 79
        echo twig_escape_filter($this->env, (isset($context["firmPesel"]) || array_key_exists("firmPesel", $context) ? $context["firmPesel"] : (function () { throw new RuntimeError('Variable "firmPesel" does not exist.', 79, $this->source); })()), "html", null, true);
        echo "\"
                   aria-describedby=\"firmNipHelp\" placeholder=\"PESEL\">
        </div>
        <small id=\"sfirmPesel\" class=\"form-text text-muted\">PESEL firmy -opcjonalnie (jeśli wystawcą jest np. osoba fizyczna)</small>
    </div>


    <div class=\"form-group\">
        <label for=\"firmAccount1\">bank, numer konta</label>
        <input type=\"text\" class=\"form-control firmAccount\" id=\"firmAccount1\" name=\"firmAccount1\" value=\"";
        // line 88
        echo twig_escape_filter($this->env, (isset($context["firmAccount1"]) || array_key_exists("firmAccount1", $context) ? $context["firmAccount1"] : (function () { throw new RuntimeError('Variable "firmAccount1" does not exist.', 88, $this->source); })()), "html", null, true);
        echo "\"
               aria-describedby=\"firmAccount1Help\" placeholder=\"numer konta -obowiązkowy\">

        <input type=\"text\" class=\"form-control firmAccount\" id=\"firmAccount2\" name=\"firmAccount2\" value=\"";
        // line 91
        echo twig_escape_filter($this->env, (isset($context["firmAccount2"]) || array_key_exists("firmAccount2", $context) ? $context["firmAccount2"] : (function () { throw new RuntimeError('Variable "firmAccount2" does not exist.', 91, $this->source); })()), "html", null, true);
        echo "\"
               aria-describedby=\"firmAccount2Help\" placeholder=\"nazwa banku -opcjonalnie\">

        <small id=\"sfirmAccount\" class=\"form-text text-muted\">Obowiązkowy tylko numer konta, nazwa opcjonalna</small>
    </div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 100
    public function block_base_nav_footer_scripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_footer_scripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "base_nav_footer_scripts"));

        // line 101
        echo "
    <script>

        /** odszukaj element input, wyciągnij z nich funkcyjne klasy nez duplikacji
         *  dla każdej z nich sprawdź, czy jest na liście błędów,
         *  jeśli tak -dodaj klasę error, jeśli nie usuń klasę error
         */
        function do_with_error_class() {

            var input_list = document.getElementsByTagName('input');

            // pobieram wszystkie klasy:
            var form_input_class_list = [];
            for(var i=0;i<input_list.length;i++) {
                //input_list[i].classList.contains(\"active\");
                for(var j=0;j<input_list[i].classList.length;j++) {
                    var one_class = input_list[i].classList[j];
                    if((one_class != 'form-control') && (form_input_class_list.indexOf(one_class) < 0)) {
                        form_input_class_list.push(one_class);
                    }
                }
            }

            //alert('znalezione klasy: ' + form_input_class_list );
            // firmName,firmAdres,mInputEmail,firmNip,firmRegon,firmPesel,firmAccount

            // to do wyświetlenia tylko
            var errors_message_list = [];
            ";
        // line 129
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["errors_message_list"]) || array_key_exists("errors_message_list", $context) ? $context["errors_message_list"] : (function () { throw new RuntimeError('Variable "errors_message_list" does not exist.', 129, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 130
            echo "                errors_message_list.push('";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "');
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 132
        echo "
            var errors_message_redclass_list = [];
            ";
        // line 134
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["errors_message_redclass_list"]) || array_key_exists("errors_message_redclass_list", $context) ? $context["errors_message_redclass_list"] : (function () { throw new RuntimeError('Variable "errors_message_redclass_list" does not exist.', 134, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 135
            echo "                errors_message_redclass_list.push('";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "');
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 137
        echo "
            // dla każdej z klas pobieram elementy i dodaję lub usuwam klasę error_input
            for(var k=0;k<form_input_class_list.length;k++) {
                // klasa, którą sprawdzam teraz:
                var one_class = form_input_class_list[k];
                // pobieram wszystkie elementy z tą klasą:
                var one_class_elements_list = document.getElementsByClassName(one_class);
                //console.log('elementy z klasą: \"' + one_class + '\" --> szt: ' + one_class_elements_list.length)
                // dla każdego z nich:
                for(var l=0;l<one_class_elements_list.length;l++) {
                    // jeśli ta klasa jest w błędnych -> zaznaczam error
                    if(  errors_message_redclass_list.indexOf(one_class) >= 0 ) {
                        //console.log('powinien być error')
                        if(!one_class_elements_list[l].classList.contains(\"error\")) {
                            //console.log('nie zawiera, więc dodaję error')
                            one_class_elements_list[l].classList.add(\"error\");
                        }
                    }else{
                        //console.log('NIE powinno być erroru')
                        if(one_class_elements_list[l].classList.contains(\"error\")) {
                            //console.log('zawiera, więc usuwam error')
                            one_class_elements_list[l].classList.remove(\"error\");
                        }
                    }
                }
            }
        }

        do_with_error_class();

    </script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "customers/firm_edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  329 => 137,  320 => 135,  316 => 134,  312 => 132,  303 => 130,  299 => 129,  269 => 101,  259 => 100,  242 => 91,  236 => 88,  224 => 79,  212 => 70,  200 => 61,  194 => 57,  184 => 56,  167 => 48,  155 => 39,  150 => 37,  145 => 35,  140 => 33,  135 => 31,  130 => 28,  120 => 27,  102 => 12,  83 => 17,  77 => 13,  75 => 12,  72 => 11,  62 => 10,  39 => 3,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'customers/firm_edit.html.twig' #}

{% extends \"base/base_form_twocolumns_twobuttons.html.twig\" %}

{#% comment %}
    edycja danych firmy
{% endcomment #}


{% block base_form_main_upper_div %}

    {% block base_form_main_head_div %}{% endblock %}

    <div class=\"form-group\">
        <div class=\"input-group-prepend\">
            <span class=\"input-group-text\">nazwa firmy</span>
            <input type=\"text\" class=\"form-control firmName\" id=\"firmName\" name=\"firmName\" value=\"{{ firmName }}\"
                   aria-describedby=\"firmNameHelp\" placeholder=\"nazwa\">
        </div>
        <small id=\"sfirmName\" class=\"form-text text-muted\">nazwa firmy -wymagana</small>
    </div>

    <!-- ew. dropzone do wrzucenia ikonki -->

{% endblock %}

{% block base_form_main_left_div %}

    <div class=\"form-group\">
        <label for=\"firmAdres1\">adres</label>
        <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres1\" name=\"firmAdres1\" value=\"{{ firmAdres1 }}\"
               aria-describedby=\"firmAdres1Help\" placeholder=\"adres -wymagana choć jedna linia\">
        <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres2\" name=\"firmAdres2\" value=\"{{ firmAdres2 }}\"
               aria-describedby=\"firmAdres1Help\">
        <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres3\" name=\"firmAdres3\" value=\"{{ firmAdres3 }}\"
               aria-describedby=\"firmAdres1Help\">
        <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres4\" name=\"firmAdres4\" value=\"{{ firmAdres4 }}\"
               aria-describedby=\"firmAdres1Help\">
        <input type=\"text\" class=\"form-control firmAdres\" id=\"firmAdres5\" name=\"firmAdres5\" value=\"{{ firmAdres5 }}\"
               aria-describedby=\"firmAdres1Help\">

        <small id=\"sfirmAdres1\" class=\"form-text text-muted\">adres firmy -wymagany, w zależności od potrzeb ile linii. Obowiązkowa tylko pierwsza</small>
    </div>

    <div class=\"form-group\">
        <div class=\"input-group-prepend\">
            <span class=\"input-group-text\">adres email</span>
            <input type=\"email\" class=\"form-control mInputEmail\" id=\"mInputEmail\" name=\"mInputEmail\" value=\"{{ mInputEmail }}\"
                   aria-describedby=\"emailHelp\" placeholder=\"email -opcjonalnie\">
        </div>
        <small id=\"semail\" class=\"form-text text-muted\">jeśli tylko chcesz</small>
    </div>

{% endblock %}

{% block base_form_main_right_div %}

    <div class=\"form-group\">
        <div class=\"input-group-prepend\">
            <span class=\"input-group-text\">NIP</span>
            <input type=\"text\" class=\"form-control firmNip\" id=\"firmNip\" name=\"firmNip\" value=\"{{ firmNip }}\"
                   aria-describedby=\"firmNipHelp\" placeholder=\"NIP\">
        </div>
        <small id=\"sfirmNip\" class=\"form-text text-muted\">NIP firmy -opcjonalnie</small>
    </div>

    <div class=\"form-group\">
        <div class=\"input-group-prepend\">
            <span class=\"input-group-text\">REGON</span>
            <input type=\"text\" class=\"form-control firmRegon\" id=\"firmRegon\" name=\"firmRegon\" value=\"{{ firmRegon }}\"
                   aria-describedby=\"firmNipHelp\" placeholder=\"REGON\">
        </div>
        <small id=\"sfirmRegon\" class=\"form-text text-muted\">REGON firmy -opcjonalnie</small>
    </div>

    <div class=\"form-group\">
        <div class=\"input-group-prepend\">
            <span class=\"input-group-text\">PESEL</span>
            <input type=\"text\" class=\"form-control firmPesel\" id=\"firmPesel\" name=\"firmPesel\" value=\"{{ firmPesel }}\"
                   aria-describedby=\"firmNipHelp\" placeholder=\"PESEL\">
        </div>
        <small id=\"sfirmPesel\" class=\"form-text text-muted\">PESEL firmy -opcjonalnie (jeśli wystawcą jest np. osoba fizyczna)</small>
    </div>


    <div class=\"form-group\">
        <label for=\"firmAccount1\">bank, numer konta</label>
        <input type=\"text\" class=\"form-control firmAccount\" id=\"firmAccount1\" name=\"firmAccount1\" value=\"{{ firmAccount1 }}\"
               aria-describedby=\"firmAccount1Help\" placeholder=\"numer konta -obowiązkowy\">

        <input type=\"text\" class=\"form-control firmAccount\" id=\"firmAccount2\" name=\"firmAccount2\" value=\"{{ firmAccount2 }}\"
               aria-describedby=\"firmAccount2Help\" placeholder=\"nazwa banku -opcjonalnie\">

        <small id=\"sfirmAccount\" class=\"form-text text-muted\">Obowiązkowy tylko numer konta, nazwa opcjonalna</small>
    </div>

{% endblock %}


{% block base_nav_footer_scripts %}

    <script>

        /** odszukaj element input, wyciągnij z nich funkcyjne klasy nez duplikacji
         *  dla każdej z nich sprawdź, czy jest na liście błędów,
         *  jeśli tak -dodaj klasę error, jeśli nie usuń klasę error
         */
        function do_with_error_class() {

            var input_list = document.getElementsByTagName('input');

            // pobieram wszystkie klasy:
            var form_input_class_list = [];
            for(var i=0;i<input_list.length;i++) {
                //input_list[i].classList.contains(\"active\");
                for(var j=0;j<input_list[i].classList.length;j++) {
                    var one_class = input_list[i].classList[j];
                    if((one_class != 'form-control') && (form_input_class_list.indexOf(one_class) < 0)) {
                        form_input_class_list.push(one_class);
                    }
                }
            }

            //alert('znalezione klasy: ' + form_input_class_list );
            // firmName,firmAdres,mInputEmail,firmNip,firmRegon,firmPesel,firmAccount

            // to do wyświetlenia tylko
            var errors_message_list = [];
            {% for i in errors_message_list %}
                errors_message_list.push('{{ i }}');
            {% endfor %}

            var errors_message_redclass_list = [];
            {% for i in errors_message_redclass_list %}
                errors_message_redclass_list.push('{{ i }}');
            {% endfor %}

            // dla każdej z klas pobieram elementy i dodaję lub usuwam klasę error_input
            for(var k=0;k<form_input_class_list.length;k++) {
                // klasa, którą sprawdzam teraz:
                var one_class = form_input_class_list[k];
                // pobieram wszystkie elementy z tą klasą:
                var one_class_elements_list = document.getElementsByClassName(one_class);
                //console.log('elementy z klasą: \"' + one_class + '\" --> szt: ' + one_class_elements_list.length)
                // dla każdego z nich:
                for(var l=0;l<one_class_elements_list.length;l++) {
                    // jeśli ta klasa jest w błędnych -> zaznaczam error
                    if(  errors_message_redclass_list.indexOf(one_class) >= 0 ) {
                        //console.log('powinien być error')
                        if(!one_class_elements_list[l].classList.contains(\"error\")) {
                            //console.log('nie zawiera, więc dodaję error')
                            one_class_elements_list[l].classList.add(\"error\");
                        }
                    }else{
                        //console.log('NIE powinno być erroru')
                        if(one_class_elements_list[l].classList.contains(\"error\")) {
                            //console.log('zawiera, więc usuwam error')
                            one_class_elements_list[l].classList.remove(\"error\");
                        }
                    }
                }
            }
        }

        do_with_error_class();

    </script>

{% endblock %}
", "customers/firm_edit.html.twig", "/home/wiks/Dokumenty/projects/iai_task/php/iai_invoice/templates/customers/firm_edit.html.twig");
    }
}
