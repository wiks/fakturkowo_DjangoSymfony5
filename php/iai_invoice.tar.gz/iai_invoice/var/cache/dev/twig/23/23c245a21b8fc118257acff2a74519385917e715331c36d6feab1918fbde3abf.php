<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* invoices/invoice_show_common_one_row.html.twig */
class __TwigTemplate_7f353b13fe42483dd6488599b5011249308a1aef64b65ece95d1a54550c0a7f7 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_show_common_one_row.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "invoices/invoice_show_common_one_row.html.twig"));

        // line 2
        echo "
";
        // line 6
        echo "

<tr>
    <td class=\"td_border_center\">";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["loop"]) || array_key_exists("loop", $context) ? $context["loop"] : (function () { throw new RuntimeError('Variable "loop" does not exist.', 9, $this->source); })()), "index", [], "any", false, false, false, 9), "html", null, true);
        echo "</td>
    <td class=\"td_border td_left\">";
        // line 10
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["invoice_item"]) || array_key_exists("invoice_item", $context) ? $context["invoice_item"] : (function () { throw new RuntimeError('Variable "invoice_item" does not exist.', 10, $this->source); })()), "name", [], "any", false, false, false, 10), "html", null, true);
        echo "</td>
    <td class=\"td_border_center\">-</td>
    <td class=\"td_border_center\">";
        // line 12
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["invoice_item"]) || array_key_exists("invoice_item", $context) ? $context["invoice_item"] : (function () { throw new RuntimeError('Variable "invoice_item" does not exist.', 12, $this->source); })()), "items_number", [], "any", false, false, false, 12), "html", null, true);
        echo "</td>
    <td class=\"td_border_center\">";
        // line 13
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["invoice_item"]) || array_key_exists("invoice_item", $context) ? $context["invoice_item"] : (function () { throw new RuntimeError('Variable "invoice_item" does not exist.', 13, $this->source); })()), "jm", [], "any", false, false, false, 13), "html", null, true);
        echo "</td>
    <td class=\"td_border_center\">
        <table class=\"table_w100\">
            <tr>
                <td class=\"td_border td_right\">
                    ";
        // line 18
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["invoice_item"]) || array_key_exists("invoice_item", $context) ? $context["invoice_item"] : (function () { throw new RuntimeError('Variable "invoice_item" does not exist.', 18, $this->source); })()), "price_brutto", [], "any", false, false, false, 18), 2, ".", ","), "html", null, true);
        echo "
                </td>
            </tr>
            <tr>
                <td class=\"td_border td_right\">
                    ";
        // line 23
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["invoice_item"]) || array_key_exists("invoice_item", $context) ? $context["invoice_item"] : (function () { throw new RuntimeError('Variable "invoice_item" does not exist.', 23, $this->source); })()), "price_netto", [], "any", false, false, false, 23), 2, ".", ","), "html", null, true);
        echo "
                </td>
            </tr>
        </table>
    </td>
    <td class=\"td_border_center\">";
        // line 28
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["invoice_item"]) || array_key_exists("invoice_item", $context) ? $context["invoice_item"] : (function () { throw new RuntimeError('Variable "invoice_item" does not exist.', 28, $this->source); })()), "value_netto", [], "any", false, false, false, 28), 2, ".", ","), "html", null, true);
        echo "</td>
    <td class=\"td_border_center\">";
        // line 29
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["invoice_item"]) || array_key_exists("invoice_item", $context) ? $context["invoice_item"] : (function () { throw new RuntimeError('Variable "invoice_item" does not exist.', 29, $this->source); })()), "vat", [], "any", false, false, false, 29), "html", null, true);
        echo "%</td>
    <td class=\"td_border_center\">";
        // line 30
        echo twig_escape_filter($this->env, twig_number_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["invoice_item"]) || array_key_exists("invoice_item", $context) ? $context["invoice_item"] : (function () { throw new RuntimeError('Variable "invoice_item" does not exist.', 30, $this->source); })()), "value_brutto", [], "any", false, false, false, 30), 2, ".", ","), "html", null, true);
        echo "</td>
</tr>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "invoices/invoice_show_common_one_row.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 30,  92 => 29,  88 => 28,  80 => 23,  72 => 18,  64 => 13,  60 => 12,  55 => 10,  51 => 9,  46 => 6,  43 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("{# 'invoces/invoice_show_common_one_row.html.twig' #}

{# comment %}
    jeden wiersz faktury do pokazania
{% endcomment #}


<tr>
    <td class=\"td_border_center\">{{ loop.index }}</td>
    <td class=\"td_border td_left\">{{ invoice_item.name }}</td>
    <td class=\"td_border_center\">-</td>
    <td class=\"td_border_center\">{{ invoice_item.items_number }}</td>
    <td class=\"td_border_center\">{{ invoice_item.jm }}</td>
    <td class=\"td_border_center\">
        <table class=\"table_w100\">
            <tr>
                <td class=\"td_border td_right\">
                    {{ (invoice_item.price_brutto)|number_format(2, '.', ',') }}
                </td>
            </tr>
            <tr>
                <td class=\"td_border td_right\">
                    {{ (invoice_item.price_netto)|number_format(2, '.', ',') }}
                </td>
            </tr>
        </table>
    </td>
    <td class=\"td_border_center\">{{ (invoice_item.value_netto)|number_format(2, '.', ',') }}</td>
    <td class=\"td_border_center\">{{ invoice_item.vat }}%</td>
    <td class=\"td_border_center\">{{ (invoice_item.value_brutto)|number_format(2, '.', ',') }}</td>
</tr>
", "invoices/invoice_show_common_one_row.html.twig", "/home/wiks/Dokumenty/projects/iai_task/php/iai_invoice/templates/invoices/invoice_show_common_one_row.html.twig");
    }
}
